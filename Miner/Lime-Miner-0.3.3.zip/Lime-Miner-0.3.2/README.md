
<img src="https://i.imgur.com/xMwdvQv.gif">

# Lime Miner v0.3


## Main Features

* .NET - Coded in Visual Basic .NET, required framework 4.0 dependency.
 
* Codedom - No need for external library to compile

* Injection - Hide payload behind a legit process "explorer.exe"
  
 
## Prerequisites

To open project you need:

1- Visual Studio 2017+

2- This repository


## Author

* **NYAN CAT** 


## Disclaimer

I, the creator, am not responsible for any actions, and or damages, caused by this software.

You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only.

This software's main purpose is NOT to be used maliciously, or on any system that you do not own, or have the right to use.

By using this software, you automatically agree to the above.


## License

This project is licensed under the MIT License - see the [LICENSE](/LICENSE) file for details
