MAXA-Crypt Portable is a free application to securely encrypt texts, files and entire directory structures. The content can then only be read again after entering the correct password or pass phrase.
The integrated pass phrase generator allows quickly creating a strong pass phrase with 256 bit. Using this to encrypt with MAXA Crypt Portable gives you state of the art protection.

Some highlights:
1.  Practical security level of 100% 
2.  256-bit key length 
3.  Intelligent encryption algorithm 
4.  No format or size limitations for the encrypted file 
5.  Minimal encryption overhead 
6.  High size-reduction factor 
7.  Variable file name- and extension-encryption 
8.  Intelligent pass-phrase generator 
9.  Virtual keyboard 
10. No "Back Door Key" possible 
11. Online and Email Encryption 
12. Multilingual (English, German, Spanish and French) 
13. No installation needed (USB-Stick portable) 


Hard- and Software requirements:

Minimum Pentium II/266MHz, VGA, keyboard and mouse or similar. Windows 98 / SE / ME / 2000 / XP / VISTA / Windows 7 or compatible, 32 Bit or 64 Bit. 
Available as ".ZIP" and ".PAF.EXE" (portable).

Notice:
* Errors & Omissions Excepted 
* This paper reflects the technical status as of August 2011
* MAXA, the text (name) and image (logo) references are registered trademarks of MAXA Research Int�l Inc.
* Any other trademarks mentioned are the property of the registered owner.
* For more details see http://www.maxa-tools.com
