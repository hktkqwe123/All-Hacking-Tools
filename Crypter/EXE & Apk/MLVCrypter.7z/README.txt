MLV Crypter - FUD
------------------------------------------------------

Hello guys!
I'm MrLeichtVideo from Hackforums and this is my FUD Crypter.
I posted my crypter yesterday, without a stub.
This is my new post with a stub.
I hope you like my crypter and please subscribe to my youtube channels.

http://www.youtube.com/MrLeichtVideo
http://www.youtube.com/MLVMusicTV
http://www.youtube.com/SkyTalkTehVau