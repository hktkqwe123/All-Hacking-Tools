<?php

$num = 60;

$dead = 7;

$delay = 180;

$login = 'admin';

$passw = '21232f297a57a5a743894a0e4a801fc3';

$conf['masterkey'] = '1c7325';
?>