<?php

$db_host = 'localhost';

$db_name = 'drillbyt_temp';
$db_user = 'drillbyt_test';

$db_pass = '123456!';

?>