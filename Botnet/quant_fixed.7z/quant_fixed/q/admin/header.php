<?php

	if(!defined('GRANTED')) die;

?>

<html>

<head>
	
	<title>Quant [PRO] Loader</title>
	
	<link rel="stylesheet" type="text/css" href="style.css">
	
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">

</head>


<body>



<p align="center">
	<img border="0" src="quant_logo.png">
</p>

