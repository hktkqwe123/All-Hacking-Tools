<?php

if(!defined('GRANTED')) die;

include '../include/mysql.php';
mysql_connect($db_host, $db_user, $db_pass) or die('<font color=red>SQL connection filed!</font>');
mysql_select_db($db_name) or die('<font color=red>DataBase not found "'.$db_name.'"!</font>');

$from=intval($_GET['from']);
$answ = mysql_query("SELECT SQL_CALC_FOUND_ROWS * FROM bots ORDER BY birthday ASC LIMIT $from, $num");
$records = mysql_fetch_array(mysql_query('SELECT FOUND_ROWS()'));

if ($bcoun = mysql_num_rows($answ)) {

	$pages = ($records[0]/$num);

	if ($pages>1) {

		$pagestr = '<table align=center width=1150 class=table style="margin-bottom:5px;" cellpadding=1 cellspacing=1>
<tr align=center>
	<td>';
		for ($i=0;$i<$pages;$i++) {
			$pagestr .= ($i*$num==$from)?(($i+1)):('<a href="?page=bots&from='.($i*$num).'">'.($i+1).'</a>');
			if ($i+1<$pages) $pagestr .= ' - ';
		}
		$pagestr .= '</td>
</tr>
</table>
';

	}

	echo $pagestr.'<table align=center width=1150 class=table style="margin-bottom:5px;" cellpadding=1 cellspacing=1>
<tr align=center>
	<td class=table1>Bot ID</td>
	<td class=table1>System IL</td>
	<td class=table1>Version</td>
	<td class=table1>OS bits</td>
	<td class=table1>IP address</td>
	<td class=table1>Country</td>
	<td class=table1>Registrated</td>
	<td class=table1>Sync</td>
	<td class=table1>Banned to</td>
	<td class=table1>Loads</td>
	<td class=table1>Total</td>
</tr>';

	$mtime = intval(filemtime('../data/update.dat'));
	while ($row = mysql_fetch_array($answ)) {

		echo '<tr align=center '.(($row['lastknock']+60*60*24*$dead<time() or $row['orders']=='deleted')?('style="color:red;" '):(($row['lastknock']+$delay>time())?('style="color:80e192;" '):(''))).'onmouseover="this.className=\'string\';" onmouseout="this.className=\'\';">
	<td>'.$row['id'].'</td>
	<td>'.$row['il'].'</td>
	<td>'.$row['vr'].'</td>
	<td>'.$row['bt'].'</td>
	<td>'.long2ip($row['ip']).'</td>
	<td nowrap>['.$COUNTRY_CODE[$row['country']].'] '.$COUNTRY_NAME[$row['country']].'</td>
	<td>'.date('d.m.y H:i:s', $row['birthday']).'</td>
	<td>'.date('d.m.y H:i:s', $row['lastknock']).'</td>
	<td>'.(($row['nextload']>time())?(date('d M Y H:i:s', $row['nextload'])):('-')).'</td>
	<td>'.(($row['orders'])?($row['orders']):('-')).'</td>
	<td>'.(($row['onboard'])?($row['onboard']):('-')).'</td>
</tr>';

	}

	echo '<tr align=center>
	<td class=table1>Results:</td>
	<td class=table1 colspan=4>Bots in base: '.$records[0].' , show: '.$bcoun.'</td>
	<td class=table1 style="color:80e192;">online</td>
	<td class=table1>offline</td>
	<td class=table1 style="color:red;">dead</td>
	<td class=table1>&nbsp;</td>
	<td class=table1>&nbsp;</td>
	<td class=table1>&nbsp;</td>
</tr>
</table>
'.$pagestr;

}

?>