
		<center>
			<b> 
				<?
					echo '� '.date('Y').' CPPGURU Software';
				?>

			</b>
		</center>


	</body>


</html>