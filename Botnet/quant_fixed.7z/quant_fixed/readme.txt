quant_builder.exe PUBLIC RELEASE

built with gcc mingw on windows n protected with VMProtect Professional
pretty straightforward. Enter the FULL gateway url (including "http://" or "https://") and ending in .php

upload the entire 'q' folder to ur web host.

lots of love, 
caiveman