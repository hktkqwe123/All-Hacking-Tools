<?php
    $conf["login"] = "root";
    $conf["password"] = "618db9c3934872221497e0a4f3c6290a";
    $conf["observer_login"] = "observer";
    $conf["observer_password"] = "618db9c3934872221497e0a4f3c6290a";
    $conf["dbhost"] = "localhost";
    $conf["dbname"] = "a785245_ama";
    $conf["dbuser"] = "a785245_ama";
    $conf["dbpass"] = "IFuckB0Y";
?>