<?php


require 'include/internal.php';
include_once 'include/settings.php';
unset($_SESSION['parasite']);
$login_script = 'Location: ' . str_replace('/logout.php', '', $_SERVER['PHP_SELF']) . '/login/';

if ($g_special_login_code == '') {
	header($login_script);
}
else {
	header($login_script . '?code=' . $g_special_login_code);
}

exit('Redirecting to: login.php');

?>
