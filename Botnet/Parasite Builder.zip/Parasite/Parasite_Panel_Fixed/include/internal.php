<?php
	require_once("DBG.php");
	
	$db_username = ""; 
    $db_password = ""; 
    $db_host = ""; 
    $db_name = ""; 
	
	$db_options = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"); 

	define("KEY_1", "11453E10D04A01100B3A93323EDD698F");
	define("KEY_2", "THIS DOES NOT MATTER, REMOVED");
	define("ACTIVATION_CODE", "THIS DOES NOT MATTER, REMOVED");
	try 
    { 
       $db = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8", $db_username, $db_password, $db_options); 
    } 
    catch(PDOException $ex) 
    { 
		DEBUG_PRINT("Failed to connect to the database: " . $ex->getMessage());
	} 
	
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); 
    
	if(function_exists("get_magic_quotes_gpc") && get_magic_quotes_gpc()) 
    { 
        function undo_magic_quotes_gpc(&$array) 
        { 
            foreach($array as &$value) 
            { 
                if(is_array($value)) 
                { 
                    undo_magic_quotes_gpc($value); 
                } 
                else 
                { 
                    $value = stripslashes($value); 
                } 
            } 
        } 
     
        undo_magic_quotes_gpc($_POST); 
        undo_magic_quotes_gpc($_GET); 
        undo_magic_quotes_gpc($_COOKIE); 
    } 
	
	function IsValidIP($IP)
	{
		if (filter_var($IP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === FALSE) 
		{
			return false;
		}

		return true;
	}
	
	function GetIPAddress() 
	{
		$IPKeys = array("HTTP_CLIENT_IP", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP", "HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "REMOTE_ADDR");
		foreach ($IPKeys as $Key) 
		{
			if (array_key_exists($Key, $_SERVER) === true) 
			{
				foreach (explode(",", $_SERVER[$Key]) as $IP) 
				{
					$IP = trim($IP);
					if (IsValidIP($IP))
					{
						return $IP;
					}
				}
			}
		}

		return isset($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : false;
	}
	
	// Change this to your timezone
	date_default_timezone_set("UTC");
	
    header("Content-Type: text/html; charset=utf-8"); 
	
    session_start(); 
?>