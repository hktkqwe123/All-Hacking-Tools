<?php
if(!isset($initialized))
{
	include('../../../pages/404.php');
}
?>