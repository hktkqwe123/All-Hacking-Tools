<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}
/*
This is basic configuration file for plugin. 
*/
$plugin_name = "Example Plugin";
$plugin_guid = "9466eb18-8ae0-4341-b769-6f0b3b9cc290"; // GUID should be different for diferent versions
$plugin_desc = "This is example plugin!";
$plugin_author = "Parasite";
$plugin_icon = "<i class='fa fa-puzzle-piece'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = true; // Declares that the plugin have code that needs to be executed on a target machine
?>