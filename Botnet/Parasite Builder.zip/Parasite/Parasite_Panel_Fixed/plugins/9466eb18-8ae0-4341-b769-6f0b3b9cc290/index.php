<?php
/*index.php is not being used, its just here to prevent indexing on poorly secured servers*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}
?>
