<?php 
/*
Inclusion sequence:
1. include.php --> Make queries etc. Its included before anything is prnted. 
2. header.php --> Make queries etc. Script is executed just before body.php
3. body.php
4. footer.php
*/

	if(!isset($initialized))
	{
		include('../../pages/404.php');
	}
?>