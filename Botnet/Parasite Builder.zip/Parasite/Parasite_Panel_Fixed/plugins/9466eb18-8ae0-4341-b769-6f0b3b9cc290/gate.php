<?php
/*
This script is used to receive data from the plugin client!
The data that plugin is sending is in the $_POST[] variable. You can use your own methods for
communicating with clients but its important to respect user preferances about http/https.
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}

if(isset($_POST['data']))
{
	// All data is in the $_POST[], no need for encoding/encrypting data on the client side. Its already been taken care of!
	// Use function SendResponse($data); to send data to the client. 
	
	SendResponse("Received data is : " . $_POST['data']); // 
	// Script stops executing after SendResponse() is called.
}
?>