<?php
/*
This is the part of the plugin that is included in the plugin page in the panel. 
Here you can show tables, fetched data from the databases etc.
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}
	
?>
<div class="row">
	<div class="col-lg-12">
	This is a plugin!
	</div>
</div>