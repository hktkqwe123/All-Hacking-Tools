<?php
/*
This is the plugin activation script! You should handle all things that are needed for plugin to work like
creating new tables in the database etc.
*/

if(!isset($initialized))
{
	include('../../pages/404.php');
}

require("config.php");

// Create tables or whatever 

?>