<?php 
	if(!isset($initialized))
	{
		include('../../pages/404.php');
	}
	
	if(isset($_GET['page']) && $_GET['page'] == "33f7b140-94ac-4aad-8a31-6076200097d6")
	{
		include_once("config.php");
		
		if(isset($_GET['action']) && $_GET['action'] == 'download')
		{
			$file = 'plugins/' . $plugin_guid . '/HVNC_Tool.zip';

			if (file_exists($file)) {
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="HVNC_Tool.zip"');
				header('Expires: 0');
				header('Cache-Control: no-cache');
				header('Content-Length: ' . filesize($file));
				readfile($file);
				exit;
			}
		}
	}
	
?>