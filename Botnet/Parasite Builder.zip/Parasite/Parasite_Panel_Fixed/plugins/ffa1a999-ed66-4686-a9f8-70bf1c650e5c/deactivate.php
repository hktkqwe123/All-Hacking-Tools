<?php
/*
This script is used to deactivate plugin. You should undo all actions created in activate script like creating tables etc...
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}


require("config.php");

// Create tables or whatever 
$query = "ALTER TABLE users DROP admin;";

try 
{ 
	// Execute the query against the database 
	$stmt = $db->prepare($query); 
	$stmt->execute(); 
} 
catch(PDOException $ex) 
{ 
	// Note: On a production website, you should not output $ex->getMessage(). 
	// It may provide an attacker with helpful information about your code.  
	DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
} 

$query = "ALTER TABLE users DROP last_visit;";

try 
{ 
	// Execute the query against the database 
	$stmt = $db->prepare($query); 
	$stmt->execute(); 
} 
catch(PDOException $ex) 
{ 
	// Note: On a production website, you should not output $ex->getMessage(). 
	// It may provide an attacker with helpful information about your code.  
	DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
} 


?>