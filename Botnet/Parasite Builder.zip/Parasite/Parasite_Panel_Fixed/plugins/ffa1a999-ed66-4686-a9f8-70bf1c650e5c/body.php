<?php 
if(!isset($initialized))
{
	include('../../pages/404.php');
}
?>

<?php if(isset($_GET['edit'])): ?>
<style>
.col_u {
    float: left;
    width: 50%;
}

/* Clear floats after the columns */
.row_u:after {
    content: "";
    display: table;
    clear: both;
}
</style>
<div class="row">
	<div class="col-lg-5">
		<!--box -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-edit"></i> Permissions - <?php echo $_GET['edit'] ?></h3>
			</div>
			<div class="panel-body">
			<?php if(!$row): ?>
			User not found in the database!
			<?php else: ?>
			
				<form action="?page=ffa1a999-ed66-4686-a9f8-70bf1c650e5c&edit=<?php echo $_GET['edit'] ?>" method="post">
				<div class="row_u">
					<div class="col_u">
					<h4>Main Pages</h4>
					<p>
						
						<div class="checkbox">
							<label><input type="checkbox" checked disabled> Dashboard</input></label>
						</div>
						<div class="checkbox">
							<label><input type="checkbox" name="page[]" value="clients" <?php echo (in_array("clients", $pages_allowed)) ? "checked" : "" ?>> Clients</input></label>
						</div>
						<div class="checkbox">
							<label><input type="checkbox" name="page[]" value="tasks" <?php echo (in_array("tasks", $pages_allowed)) ? "checked" : "" ?>> Tasks</input></label>
						</div>
						<div class="checkbox">
							<label><input type="checkbox" name="page[]" value="settings" <?php echo (in_array("settings", $pages_allowed)) ? "checked" : "" ?>> Settings</input></label>
						</div>
						<div  class="checkbox">
							<label><input type="checkbox" name="page[]" value="plugins" <?php echo (in_array("plugins", $pages_allowed)) ? "checked" : "" ?>> Plugins</input></label>
						</div>
					</p>
					</div>
					<div class="col_u">
					<h4>Plugin Pages</h4>
					<p>
						<?php foreach($rows_plugin as $row_plugin): ?>
							<div class="checkbox">
								<label><input name="page[]" type="checkbox" value="<?php echo $row_plugin['guid']; ?>" <?php echo (in_array($row_plugin['guid'], $pages_allowed)) ? "checked" : "" ?>><?php echo $row_plugin['name']; ?></input></label>
							</div>
						<?php endforeach ?>
					</p>
					</div>
				</div>
					
				<br>
					<div style="text-align: center">
						<button class="btn btn-sm btn-primary btn-flat" type="submit" name="set_permissions" href="#">Update Permissions</button>
					</div>
				</form>
				
			<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php else: ?>
<div class="row">
	<div class="col-lg-8">
		<!--box -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-users"></i> Users</h3>
			</div>
			<div class="panel-body">
				<table id="users_table" class="table table-hover">
					<thead>
						<tr>
							<th>Username</th>
							<th>Last Login</th>
							<th>Last Visit</th>
							<th>Admin</th>
							<th>Options</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($rows as $row):?>
						<tr>
							<td><?php echo $row['username']; ?></td>
							<td><?php echo ($row['last_login'] == 0) ? "Never" : date("j M Y, G:i", $row['last_login']) ?></td>
							<td><?php echo ($row['last_visit'] == 0) ? "Never" : date("j M Y, G:i", $row['last_visit']) ?></td>
							<td><?php echo ($row['admin'] == 0) ? "No" : "Yes" ?></td>
							<td>
								<a href="?page=ffa1a999-ed66-4686-a9f8-70bf1c650e5c&delete=<?php echo $row['username']; ?>" data-toggle="tooltip" data-placement="left" title="Delete User"><i class="fa fa-close"></i></a>&nbsp;
								<a href="?page=ffa1a999-ed66-4686-a9f8-70bf1c650e5c&edit=<?php echo $row['username']; ?>" data-toggle="tooltip" data-placement="left" title="Edit Permissions"><i class="fa fa-edit"></i></a>&nbsp;
								<?php if ($row['admin'] == 0) : ?><a href="?page=ffa1a999-ed66-4686-a9f8-70bf1c650e5c&admin=<?php echo $row['username']; ?>" data-toggle="tooltip" data-placement="left" title="Give Admin Status (User will have access to all pages regardless of page permissions)"><i class="fa fa-bolt"></i></a><?php endif; ?>
								
							</td>
						</tr>
						<?php endforeach ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<!--box -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-title"><i class="fa fa-user-plus"></i> Create New Account</h3>
			</div>
			<div class="panel-body">
				<form action="?page=ffa1a999-ed66-4686-a9f8-70bf1c650e5c" method="post">
					<p>
						<label>Username</label>
						<input style="color:black;" name="username" class="form-control"></input>
					</p>
					<p>
						<label>Password</label>
						<input style="color:black;" name="pswd" class="form-control"></input>
					</p>
					<p>
						<label>Confirm Password</label>
						<input style="color:black;" name="cpswd" class="form-control"></input>
					</p>
					<div style="text-align: center">
						<button class="btn btn-sm btn-primary btn-flat" type="submit" name="create_account" href="#">Create Account</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>