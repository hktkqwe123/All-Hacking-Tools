<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}

$plugin_name = "User Management";
$plugin_guid = "ffa1a999-ed66-4686-a9f8-70bf1c650e5c"; // GUID should be different for diferent versions
$plugin_desc = "Create and manage user accounts!";
$plugin_author = "Parasite";
$plugin_icon = "<i class='fa fa-users'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = false;
?>