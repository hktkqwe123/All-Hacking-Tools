<?php 
if(!isset($initialized))
{
	include('../../pages/404.php');
}
?>
<script src="assets/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="assets/datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript">$("#users_table").dataTable();</script>