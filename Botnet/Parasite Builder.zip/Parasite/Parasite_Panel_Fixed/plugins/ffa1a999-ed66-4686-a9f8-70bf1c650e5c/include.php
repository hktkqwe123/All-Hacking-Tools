<?php 
	if(!isset($initialized))
	{
		include('../../pages/404.php');
	}
	
	// update last seen
	$query = "UPDATE users SET last_visit = :last_visit WHERE username = :username"; 
				
	$query_params = array(':username' => $_SESSION['parasite']['username'], ':last_visit'=> $time); 
	
	try 
	{ 
		// Execute the query against the database 
		$stmt = $db->prepare($query); 
		$stmt->execute($query_params); 
	} 
	catch(PDOException $ex) 
	{ 
		// Note: On a production website, you should not output $ex->getMessage(). 
		// It may provide an attacker with helpful information about your code.  
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
	
	$pages_allowed_g = array(); // because in array not working in multi
	
	$query = "SELECT page_allowed FROM user_permissions WHERE username = :username";
	$query_params = array(':username' => $_SESSION['parasite']['username']);
	
	try 
	{ 
		// Execute the query against the database 
		$stmt = $db->prepare($query); 
		$stmt->execute($query_params); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); // Will print debug message and stop the script execution by calling die();
	} 
	$rows_permissions = $stmt->fetchAll();
	
	foreach($rows_permissions as $row_permissions)
	{
		array_push($pages_allowed_g, $row_permissions['page_allowed']);
	}
	
	if(!$_SESSION['parasite']['admin']) // Applicable to only non admin members
	{
		if(isset($_GET['page']) && $_GET['page'] != 'dashboard')
		{
			if(!in_array($_GET['page'], $pages_allowed_g))
			{
				header("Location: ?page=dashboard&error=You do not have permissions to see this page! Contact administrator for more info!");
				die("No permission!");
			}
		}
	}
	
	
	
	
	
	/*if(isset($_GET['page']) && $_GET['page'] == 'ffa1a999-ed66-4686-a9f8-70bf1c650e5c')
	{
		header("Location: ?page=dashboard&error=You do not have permissions to see this page! Contact administrator for more info!");
		die();
	}*/
	
	// Select from user_permissions where user_id = session id
	/*
	then check permission table
	
	*/
	
	
	
?>