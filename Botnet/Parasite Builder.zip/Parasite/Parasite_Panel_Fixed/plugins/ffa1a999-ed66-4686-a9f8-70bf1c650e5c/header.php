<?php 
if(!isset($initialized))
{
	include('../../pages/404.php');
}


// Create new account
if(!empty($_POST)) // If we dont have any POST data...Could we use isset?
{
	// Create user
	if(isset($_POST['create_account']))
	{
		// Validate username here
		if (!preg_match('/^[a-z\d_]{5,20}$/i', $_POST['username'])) 
		{
			$error = "Username can only consist of alpha-numeric, underscores, and has minimum 5 character and maximum 20 character!";
		}
		
		if($_POST['pswd'] != $_POST['cpswd'] && $error == "")
		{
			$error = "Passwords do not match!";
		}
		
		if($error == "")
		{
			$query = "SELECT * FROM users WHERE username = :username"; 
				
			$query_params = array(':username' => $_POST['username']); 
			
			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$result = $stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				// Note: On a production website, you should not output $ex->getMessage(). 
				// It may provide an attacker with helpful information about your code.  
				DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
			} 
			
			$row = $stmt->fetch(); 
			
			if(!$row) 
			{
				$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));
				
				$password = hash('sha256', $_POST['pswd'] . $salt); 
				
				for($round = 0; $round < 65536; $round++) 
				{ 
					$password = hash('sha256', $password . $salt); 
				} 
				 
				// Insert new user to db
				$query = "INSERT INTO users ( 
							username, 
							password, 
							salt
						) VALUES ( 
							:username, 
							:password, 
							:salt
						)"; 
			 
				$query_params = array( 
						':username' => $_POST['username'], 
						':password' => $password, 
						':salt' => $salt
				); 
			 
				try 
				{ 
					// Execute the query to create the user 
					$stmt = $db->prepare($query); 
					$stmt->execute($query_params); 
				} 
				catch(PDOException $ex) 
				{ 
					// Note: On a production website, you should not output $ex->getMessage(). 
					// It may provide an attacker with helpful information about your code.  
					DEBUG_PRINT("Failed to run query: 2". $ex->getMessage()); 
				}
				
				$notice = "Account created with success!";
			}
			else
			{
				$error = "That username is already taken! Please use another one!";
			}
		}
	}
	elseif(isset($_POST['set_permissions']))
	{
		// Strip all permissions from the db
		$query = "DELETE FROM user_permissions WHERE username = :username";
		
		$query_params = array(':username' => $_GET['edit']); 
			
		try 
		{ 
			// Execute the query against the database 
			$stmt = $db->prepare($query); 
			$result = $stmt->execute($query_params); 
		} 
		catch(PDOException $ex) 
		{ 
			// Note: On a production website, you should not output $ex->getMessage(). 
			// It may provide an attacker with helpful information about your code.  
			DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
		} 
		
		// Insert new permissions
		
		if(isset($_POST['page']))
		{
			foreach($_POST['page'] as $page_permission)
			{
				// Insert new user to db
				$query = "INSERT INTO user_permissions ( 
							username, 
							page_allowed
						) VALUES ( 
							:username, 
							:page_allowed
						)"; 
			 
				$query_params = array( 
						':username' => $_GET['edit'], 
						':page_allowed' => $page_permission
				); 
			 
				try 
				{ 
					// Execute the query to create the user 
					$stmt = $db->prepare($query); 
					$stmt->execute($query_params); 
				} 
				catch(PDOException $ex) 
				{ 
					// Note: On a production website, you should not output $ex->getMessage(). 
					// It may provide an attacker with helpful information about your code.  
					DEBUG_PRINT("Failed to run query: 2". $ex->getMessage()); 
				}
				
				
			}
		}
		$notice = "Page permissions edited with success!";
	}
	
}



if(isset($_GET['edit']) || isset($_GET['delete']) || isset($_GET['admin']))
{
	$query = "SELECT * FROM users WHERE username = :username";
	$query_params = array(':username' => $_GET['edit']);
	
	try 
	{ 
		// Execute the query against the database 
		$stmt = $db->prepare($query); 
		$stmt->execute($query_params); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); // Will print debug message and stop the script execution by calling die();
	} 
	$row = $stmt->fetch();
}

if(isset($_GET['admin']))
{
	// check if the current user is admin, only admin can delete and give admin permissions, or block access to this plugin to non admin users
	
	// Update
	$query = "UPDATE users SET 
		admin = 1
		WHERE username = :username";


	$query_params = array(
		':username' => $_GET['admin']);
	
	try 
	{ 
		// These two statements run the query against your database table. 
		$stmt = $db->prepare($query); 
		$result = $stmt->execute($query_params); 
		$notice = "Admin status set successifully!";
	} 
	catch(PDOException $ex) 
	{ 
		// Note: On a production website, you should not output $ex->getMessage(). 
		// It may provide an attacker with helpful information about your code.  
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	}
	
}

if(isset($_GET['delete']))
{
	// check if the current user is admin, only admin can delete and give admin permissions, or block access to this plugin to non admin users
	if($_SESSION['parasite']['username'] == $_GET['delete'])
	{
		$error = "You can not delete your own account!";
	}
	else
	{
		// Update
		$query = "DELETE FROM users
			WHERE username = :username";


		$query_params = array(
			':username' => $_GET['delete']);
		
		try 
		{ 
			// These two statements run the query against your database table. 
			$stmt = $db->prepare($query); 
			$result = $stmt->execute($query_params); 
			$notice = "User account deleted successifully!";
		} 
		catch(PDOException $ex) 
		{ 
			// Note: On a production website, you should not output $ex->getMessage(). 
			// It may provide an attacker with helpful information about your code.  
			DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
		}
	}
	
	
}

$pages_allowed = array(); // because in array not working in multi

if(isset($_GET['edit']))
{
	$query = "SELECT page_allowed FROM user_permissions WHERE username = :username";
	$query_params = array(':username' => $_GET['edit']);
	
	try 
	{ 
		// Execute the query against the database 
		$stmt = $db->prepare($query); 
		$stmt->execute($query_params); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); // Will print debug message and stop the script execution by calling die();
	} 
	$rows_permissions = $stmt->fetchAll();
	
	foreach($rows_permissions as $row_permissions)
	{
		array_push($pages_allowed, $row_permissions['page_allowed']);
	}
	
}



// This page will check for page and restrict it
$query = "SELECT * FROM users";
	
try 
{ 
	// Execute the query against the database 
	$stmt = $db->prepare($query); 
	$stmt->execute(); 
} 
catch(PDOException $ex) 
{ 
	DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); // Will print debug message and stop the script execution by calling die();
} 
$rows = $stmt->fetchAll();
	
?>