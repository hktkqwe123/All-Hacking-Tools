<?php
/*
This script is used to receive data from the plugin client! It will be included the gate.php. 
The data that plugin is sending is in the $_POST[] variable. You can use your own methods foreach
communicating with clients but its important to respect user preferances about http/https.
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}

if(isset($_POST['data']))
{
	// All data is in the $_POST[], no need for encoding/encrypting data on the client side. Its already been taken care of!
	
	SendResponse("Received data is : " . $_POST['data'] . " concurrent data : ". $_POST['new_data']); // 
}
?>