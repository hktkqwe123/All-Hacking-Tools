<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}

$plugin_name = "Win License Recovery";
$plugin_guid = "d18ec754-a7f0-4dc3-8ad5-164da2ba1b9e"; // GUID should be different for diferent versions
$plugin_desc = "Recovers product keys from various software!";
$plugin_author = "RonnyRoy";
$plugin_icon = "<i class='fa fa-key'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = true;
?>