<?php 
	if(!isset($initialized))
	{
		include('../../pages/404.php');
	}
	if(isset($_GET['page']) && $_GET['page'] == "44786606-0ad6-4b84-8884-6fa8856368d9")
	{
		include_once("config.php");
	
		if(isset($_GET['action']) && $_GET['action'] == 'download')
		{
			$file = 'plugins/' . $plugin_guid . '/ProxyTool.zip';

			if (file_exists($file)) {
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="ProxyTool.zip"');
				header('Expires: 0');
				header('Cache-Control: no-cache');
				header('Content-Length: ' . filesize($file));
				readfile($file);
				exit;
			}
		}
	}
	
	
?>