<?php
/*
This script is used to receive data from the plugin client! It will be included the gate.php. 
The data that plugin is sending is in the $_POST[] variable. You can use your own methods foreach
communicating with clients but its important to respect user preferances about http/https.
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}


// All data is in the $_POST[], no need for encoding/encrypting data on the client side. Its already been taken care of!
if(isset($_POST['get_data']) && isset($_POST['hwid']))
{
	//Query active sessions and make a list
	//test.com|8080$other.com|1234
	
	$query = "SELECT * FROM reverse_proxy WHERE hwid = :hwid AND (expiration = 0 OR expiration > {$time})";
	$query_param = array(':hwid' => $_POST['hwid']);
	try 
	{ 
		$stmt = $db->prepare($query); 
		$stmt->execute($query_param); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
	
	$proxy_rows = $stmt->fetchAll();
	
	if($proxy_rows)
	{
		$response = "";
	
		foreach($proxy_rows as $row)
		{
			$response .= $row['domain'] . "|" . $row['port'] ."$";
		}
		
		SendResponse($response); // 
	}
	else
	{
		SendResponse("No active sessions!");
	}
	
	
	
	
}
	
	
	
	

?>