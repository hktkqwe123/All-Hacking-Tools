<?php
/*
This is the plugin activation script! You should handle all things that are needed for plugin to work like
creating new tables in the database etc.

*/

if(!isset($initialized))
{
	include('../../pages/404.php');
}

require("config.php");

// Create tables or whatever 
// Create tables or whatever 
// Create table etc
$query = "CREATE TABLE IF NOT EXISTS reverse_proxy (
  id int(255) NOT NULL,
  session_id varchar(255) NOT NULL,
  domain varchar(255) NOT NULL,
  port varchar(255) NOT NULL,
  hwid varchar(255) NOT NULL,
  expiration int (32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

try 
{ 
	// Execute the query against the database 
	$stmt = $db->prepare($query); 
	$stmt->execute(); 
} 
catch(PDOException $ex) 
{ 
	// Note: On a production website, you should not output $ex->getMessage(). --> Handled by DEBUG_PRINT fuction that is defined in "include/common.php"
	// It may provide an attacker with helpful information about your code.  
	DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
} 

$query = "ALTER TABLE reverse_proxy ADD PRIMARY KEY (id);";

try 
{ 
	// Execute the query against the database 
	$stmt = $db->prepare($query); 
	$stmt->execute(); 
} 
catch(PDOException $ex) 
{ 
	// Note: On a production website, you should not output $ex->getMessage(). 
	// It may provide an attacker with helpful information about your code.  
	DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
} 

$query = "ALTER TABLE reverse_proxy MODIFY id int(255) NOT NULL AUTO_INCREMENT";

try 
{ 
	// Execute the query against the database 
	$stmt = $db->prepare($query); 
	$stmt->execute(); 
} 
catch(PDOException $ex) 
{ 
	// Note: On a production website, you should not output $ex->getMessage(). 
	// It may provide an attacker with helpful information about your code.  
	DEBUG_PRINT("Failed to run query: " . $ex->getMessage());
}
?>