<?php 
if(!isset($initialized))
{
	include('../../pages/404.php');
}
?>
<!-- Modal -->
<div class="modal fade" id="client_info" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close fa-inverse"></i></button>
				<h4 class="modal-title" style="text-align: center" id="ModalLabel">Extended Info</h4>
				<div id="Client_Info_Content"></div>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>



<script type="text/javascript">

function LoadClientInfo(hwid){
	var link = 'pages/clientinfo.php?hwid=' + hwid;
	$('#Client_Info_Content').load(link);
	//$("#ModalLabel").text("Extended info for " + hwid);
}
</script>
<script src="assets/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="assets/datatables/dataTables.bootstrap.min.js" type="text/javascript"></script>

<script type="text/javascript">$("#password_table").dataTable();</script>