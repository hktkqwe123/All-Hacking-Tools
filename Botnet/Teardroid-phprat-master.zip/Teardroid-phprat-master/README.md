# Teardroid-phprat


its easy to use android php rat the best part is no port forwarding needed also work as ransomware 

# requirement:
1.android studio

2.website

# version 3.0 

![Screenshot](https://github.com/ScRiPt1337/Teardroid-phprat/blob/master/Capture.PNG)

# how to use
how to setup : https://youtu.be/nbs0c-pfYOY

visit our website : https://www.hacksec.in

# Contact us
email : anon42237@gmail.com
https://discord.gg/5CjQacc
