Die "tool-store.exe" ist die Stub, nicht aus dem Binder Verzeichnis nehmen!

