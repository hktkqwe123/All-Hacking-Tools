// Stub Information //

If you have no prior-experience with stubs read this:

- Don't rename Stub.exe
- Don't move Stub.exe
- Keep the Stub.exe and builder in the same location!
- Don't scan on Virus Total, any other file distributing websites

If you do any of those the Keylogger will not be built correctly and the server corrupted.
Also, Stub.exe is not the keylogger, just ignore it.

// End //
