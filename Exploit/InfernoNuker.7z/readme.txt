
  +--------------------------------------+
  +--=[  Inferno Nuker Beta Release  ]=--+
  +--=[ coded �by Inferno Industries ]=--+
  +--------------------------------------+

..:What's this?:..
This nuker uses known exploits to crash Windows 95, 98 and NT 3.x
machines. Most target computers will see the famous "Blue screen
of death" after you nuked them, some other systems will just reboot.

..:How does it work?:..
OK, if you don't know anything about socket programming, skip this
section ;) The nuker first sends oversized IGMP packets, then it
sends an OOB dummy buffer to port 139 (NetBIOS) after connecting
via TCP. If you selected to kill firewalls, the nuker first tries to
connect to ports 1-80 (this kills many port-listeners and perhaps
some real firewalls). Later versions will support an ICMP flood.

..:Problems?:..
Problem: I get an error message like "Incompatible winsock version"...
Answer:  You're probably using Win 95. Visit the Micro$oft homepage
         and download the "Winsock 2 update" there.
Problem: I don't know the IP ot the hostname of my victim.
Answer:  If you are in a LAN, just use his computername. If you are
         not, read the "IP- and hostnames-FAQ" on the Inferno
         Industries homepage.
Problem: Nothing seems to happen on victim's computer.
Answer:  Make sure your victim does not use NT4/2000, Win98 or any
         higher version of Windoze. Make sure he didn't patch his
         computer against nukes. If it still does not work: BAD LUCK!

..:Contact:..
This program was (c)oded by kR�$T�, leader and webmaster of
Inferno Industries and coder of MoSucker trojan.
Visit our homepage at http://infernoindustries.cjb.net
If there yre questions, post them in the forum or ask per IRC chat.
DON'T EVER THINK OF ASKING: "YOUR NUKER DOES NOT WORK, WHY?"
Thank you ;)


friendly greetings fly out to the [ii] crew, to my friends, to
Winamp and to all the users of this program! Have fun =)
                                                          kR�$T� [ii]

[release date: may 8th, 2k++]